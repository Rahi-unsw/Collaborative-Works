function Trajectory
clear all;clc;close all
addpath ND_Sort;
path = pwd;
path1 = strcat(pwd,filesep,'SingleObjectiveResults');
path2 = strcat(pwd,filesep,'BiObjectiveResults');
runs = 31;

for i = 3:3
    cd(path1);  % single-obj
    load(strcat('Archive_Result_Run_',num2str(i),'.mat'));
    aa = archive.f;
    cd(path);
    
    cd(path2); % single-obj
    load(strcat('Archive_Result_Run_',num2str(i),'.mat'));
    bb = archive.f;
    cd(path);
    
    % overall maximum and minimum bound;
    ff = [aa(1:50000,1:2);bb(1:50000,1:2)];
    f_max = max(ff);f_min = min(ff);
    
    aa_norm = (aa(1:50000,1:2)-f_min)./(f_max-f_min);
    bb_norm = (bb(1:50000,1:2)-f_min)./(f_max-f_min);
    
    % Single-objective
    figure;
%     subplot(2,1,1)
    plot(aa_norm(:,1),aa_norm(:,2),'r.');hold on;
    line([0 1],[0 1],'Color','k','LineWidth',2);
    grid on
    xlabel('f_1');ylabel('f_2')
    legend('Trajectory of single-objective EA','Optimal trajectory','northwest')
    % Bi-objective
    %     figure(i);
   figure;
    plot(bb_norm(:,1),bb_norm(:,2),'b.');hold on;
    line([0 1],[0 1],'Color','k','LineWidth',2);
    grid on
    xlabel('f_1');ylabel('f_2')
    legend('Trajectory of bi-objective EA','Optimal trajectory','northwest')
    % Improvement by local search after bi-objective search
    figure;
    [~,id] = min(bb(1:50000,3));
    bb_min_EA = bb(id,1:2);
    [~,overall_best_id] = min(bb(:,3));
    bb_min_overall = bb(overall_best_id,1:2);
    [id_fronts,~,~,~] = E_NDSort_c(bb(1:50000,1:2));
    nd = id_fronts{1};
    fnd = bb(nd,1:2);
    plot(fnd(:,1),fnd(:,2),'r.','MarkerSize',20);hold on;
    plot(bb_min_EA(:,1),bb_min_EA(:,2),'b*','MarkerSize',11);
    plot(bb_min_overall(:,1),bb_min_overall(:,2),'p','MarkerFaceColor','g','MarkerSize',12);
    grid on
    xlabel('f_1=C_{rem}');ylabel('f_2=C_{penalty}')
    legend('Pareto-front from bi-objective EA','Best soultion acheived from EA','Improved solution from LS')

 
end
return