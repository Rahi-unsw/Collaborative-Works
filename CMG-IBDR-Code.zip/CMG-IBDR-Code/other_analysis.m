clc;clear
addpath Methods;addpath Results;

No_solutions=10;
Select_testbed = 2;
DB  = Select_testbed;
[caseStudyData, DB_name] = callDatabase(DB);






%% Baseline profile (unmodified)
Baseline_profile = setOtherParameters(caseStudyData,No_solutions,Select_testbed);
Baseline_profile_A=sum(Baseline_profile.Baseline_A,1);
Baseline_profile_B=sum(Baseline_profile.Baseline_B,1);
Baseline_profile_C=sum(Baseline_profile.Baseline_C,1);
aggregated_baseline_profile=Baseline_profile.Baseline_total;

%% %% Re-scheduled profile (modified)

caseStudyData_modified=caseStudyData;
load('Overall_statistics.mat')
Shifable_devices=["WM","TD","DW"]
X_counter=0;

for i=1:length(Shifable_devices)
    device=num2str(Shifable_devices(i));
    for h=1:20
        caseStudyData_modified.(device).Baseline(h)=X_median_run(h+X_counter);
    end
    X_counter=X_counter+20;
end

Non_Shifable_devices=["LED","TV","LT","HVAC"]
% X_counter=60

for i=1:length(Non_Shifable_devices)
    device=num2str(Non_Shifable_devices(i));
    B = zeros(size(caseStudyData_modified.(device).Baseline));
    B(:,1)=caseStudyData_modified.(device).Baseline(:,1);
    if strcmp(device,'HVAC')==1
        
        for h=1:20
            for t=1:(size(B,2))
                %         caseStudyData.(device).Baseline(h)=X_median_run(h+X_counter)
                B(h,t)=X_median_run(t+X_counter);
            end
            X_counter=X_counter+t;
        end
        caseStudyData_modified.(device).Baseline=B;
        
    else
        
        for h=1:20
            for t=1:(size(B,2)-1)
                %         caseStudyData.(device).Baseline(h)=X_median_run(h+X_counter)
                B(h,t+1)=X_median_run(t+X_counter);
            end
            X_counter=X_counter+t;
        end
        caseStudyData_modified.(device).Baseline=B;
        
    end
    
end

modified_profile = setOtherParameters(caseStudyData_modified,No_solutions,Select_testbed);
modified_profile_A=sum(modified_profile.Baseline_A,1);
modified_profile_B=sum(modified_profile.Baseline_B,1);
modified_profile_C=sum(modified_profile.Baseline_C,1);
aggregated_modified_profile=modified_profile.Baseline_total;

%% Calculate flexibility
Flex_A=(Baseline_profile_A-modified_profile_A)/1000;
Flex_B=(Baseline_profile_B-modified_profile_B)/1000;
Flex_C=(Baseline_profile_C-modified_profile_C)/1000;

Total_flex_calculated=Flex_A+Flex_B+Flex_C;
Aggregated_flex=(aggregated_baseline_profile-aggregated_modified_profile)/1000;


%% Plots
figure(1)
t=24/96:24/96:24;
Y=[aggregated_baseline_profile'/1000 aggregated_modified_profile'/1000];
bar(t,Y)
legend('Baseline','Rescheduled')

figure(2)
t=24/96:24/96:24;
y1=aggregated_baseline_profile/1000; y2=aggregated_modified_profile/1000;
plot(t,y1,'mo-',t,y2,'k*-','linewidth',1)
legend('Baseline','Rescheduled')

figure(3)
t=24/96:24/96:24;
y1=Baseline_profile_A/1000; y2=modified_profile_A/1000;
Y=[y1' y2']
bar(t,Y)
% plot(t,y1,'mo-',t,y2,'k*-','linewidth',1)
legend('Baseline-A','Rescheduled-A')

figure(4)
t=24/96:24/96:24;
y1=Baseline_profile_B/1000; y2=modified_profile_B/1000;
Y=[y1' y2']
bar(t,Y)
% plot(t,y1,'mo-',t,y2,'k*-','linewidth',1)
legend('Baseline-B','Rescheduled-B')

figure(5)
t=24/96:24/96:24;
y1=Baseline_profile_C/1000; y2=modified_profile_C/1000;
Y=[y1' y2']
bar(t,Y)
% plot(t,y1,'mo-',t,y2,'k*-','linewidth',1)
legend('Baseline-C','Rescheduled-C')

figure(6)
t=24/96:24/96:24;
bar(t,Flex_A)
legend('Flexibility-A')

figure(7)
t=24/96:24/96:24;
bar(t,Flex_B)
legend('Flexibility-B')

figure(8)
t=24/96:24/96:24;
bar(t,Flex_C)
legend('Flexibility-C')

figure(9)
t=24/96:24/96:24;
DSO_flex_requirement=caseStudyData.parameterData.DSO_R/1000;
yy=[-Aggregated_flex' DSO_flex_requirement']
bar(t,yy)
legend('Flexibility-provided','DSO-Flexibility-required')

%% Typical power profile of applaince
% shiftable
WM=[250 2500 1250 250 250 610 400 180 50]/1000; % 9 points
TD=[2000 2000 2000 1600 1400 1300 500 50]/1000;  % 8 points
DW=[1000 50 2000 50 50 50 2000 100 50 40]/1000;  % 10 points

% regulatable
AC=[3000 3000 3000 3000 300 300 300 3000 3000 3000 300]/1000; % 11 points
TV=[200 200 200 200 200 200 200 200 200 200 200 200]/1000;  % 12 points
LT=[1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 1000]/1000;  % 12 points
DC=[101 101 101 101 101 101 101 101]/1000;  % 8 points



figure(10)
plot(WM,'ro-','linewidth',1)
ylim([0 2.5])
xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
xlim([1 11])
xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on

figure(11)
plot(TD,'bo-','linewidth',1)
xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 2.5])
xlim([1 11])
xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on

figure(12)
plot(DW,'ko-','linewidth',1)
xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 2.5])
xlim([1 11])
xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on

figure(13)
subplot(3,1,1)
plot(WM,'ro-','linewidth',1)
%  xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 2.5])
xlim([1 11])
%  xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on
legend('Washing machine (WM)')

subplot(3,1,2)
plot(TD,'bo-','linewidth',1)
%  xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 2.5])
xlim([1 11])
%  xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on
legend('Tumble dryer (TD)')

subplot(3,1,3)
plot(DW,'ko-','linewidth',1)
xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 2.5])
xlim([1 11])
xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on
legend('Dishwasher (DW)')

figure(14)
subplot(3,1,1)
plot(AC,'ro-','linewidth',1)
%  xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 3.5])
xlim([1 12])
%  xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on
legend('Air-conditioner (AC)')

subplot(3,1,2)
plot(TV,'bo-','linewidth',1) ;hold on
plot(LT,'m*-','linewidth',1)
%  xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 1.5])
xlim([1 12])
%  xticks([1 2 3 4 5 6 7 8 9 10 11])
grid on
legend('Telivision (TD)','Lighting (LT)')

subplot(3,1,3)
plot(DC,'ko-','linewidth',1)
xlabel('time-slots (step size = 15 minutes)')
ylabel('Power (kW)')
ylim([0 0.2])
xlim([1 12])
xticks([1 2 3 4 5 6 7 8 9 10 11 12])
grid on
legend('Desktop computer (DC)')


% otherParameters = setOtherParameters(caseStudyData,No_solutions,Select_testbed);
% otherParameters.one = setOtherParameters(caseStudyData,1,Select_testbed);
% [LB,UB] = setVariablesBounds(caseStudyData,otherParameters, Select_testbed);
% a=5;