%% Multirun
function Postprocess
clear all;clc;close all;
F=2;
if F==1
    addpath SingleObjectiveResults;
else
    addpath BiObjectiveResults;
end

no_runs = 31;
all_best = [];
for k = 1:no_runs
    load(strcat('Best_Result_Run_',num2str(k),'.mat'));
    all_best = [all_best;best.f(:,3)];
    %     load(strcat('Archive_Result_Run_',num2str(k),'.mat'));
    %     [id_fronts,~,~,~] = E_NDSort_c(archive.f(1:50000,1:2));
    %     nd = id_fronts{1};
    %     fnd = archive.f(nd,1:2);
    %
    %         figure(2)
    %         colormap('jet');
    %         [~,rank] = sort(archive.f(:,3));
    %         ff = archive.f(rank,:);
    %         scatter(ff(:,1),ff(:,2),20,1:length(rank),'.');colorbar;
    %         xlim([0 20]);ylim([0 20]);
    %
    %         plot(archive.f(1:50000,1),archive.f(1:50000,2),'ro');hold on;
    %         plot(best.f(:,1),best.f(:,2),'bo');
    %         plot(fnd(:,1),fnd(:,2),'go');
    load(strcat('Archive_Result_Run_',num2str(k),'.mat'));
    plot(archive.f(1:50000,1),archive.f(1:50000,2),'r.');
end
% Find out the statistics
stats = [min(all_best),mean(all_best),median(all_best),max(all_best),std(all_best)];
median_id = find(all_best==median(all_best));

load(strcat('Best_Result_Run_',num2str(median_id),'.mat'));
X_median_run=best.x;
F_median_run=best.f;



% Plot
load(strcat('Archive_Result_Run_',num2str(median_id),'.mat'));
steps = (50001:1:100000)';
tmp_x = [50000;(51001:1000:101000)'];
tmp_F = [archive.f(50000,3);archive.f(50001:50050,3)];
interp_data = interp1(tmp_x,tmp_F,steps);

ff = [archive.f(1:50000,3);interp_data];
curr_best = ff(1,:);
for i = 1:size(ff,1)
    tt = ff(i,:);
    if tt <= curr_best
        curr_best = tt;
    end
    conv_f(i,:) = curr_best;
end

converge = conv_f;%conv_f(end)*ones(1e5-length(conv_f),1)];

if F==1
    save('Overall_statistics_single_obj.mat','stats','F_median_run','X_median_run','median_id','converge');
else
    save('Overall_statistics_bi_obj.mat','stats','F_median_run','X_median_run','median_id','converge');
end




plot(converge,'r-');
xlabel('Number of function evaluation')
ylabel('Fitness value')
savefig('Convergence_plot.fig')

% Move files
mkdir Results
if F==1
    movefile *.mat SingleObjectiveResults
    movefile *.fig SingleObjectiveResults
else
    movefile *.mat BiObjectiveResults
    movefile *.fig BiObjectiveResults
end
return
