%% Multirun
function Driver
clear all;clc;close all;
addpath Methods;addpath ND_Sort;
% numcores = feature('numcores');
% parpool(numcores);
no_runs = 31;
for k = 1:no_runs
    optimizer(k);
end
% delete(gcp);
% Move files
mkdir SingleObjectiveResults
movefile *.mat SingleObjectiveResults
return
