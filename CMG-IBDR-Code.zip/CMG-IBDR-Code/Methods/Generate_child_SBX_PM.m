%% Simulated binary crossover and polynomial mutation
function [X_Child] = Generate_child_SBX_PM(pop,prob,param)
LB = prob.bounds(:,1)';UB = prob.bounds(:,2)';
X_Child = genetic_operator(LB,UB,param,prob,pop.x);
return

function [X_child] = genetic_operator(LB,UB,def,prob,X_parent_ordered)
[X_child] = crossover_SBX_matrix(LB,UB,def,prob,X_parent_ordered);
[X_child] = mutation_POLY_matrix(LB,UB,def,prob,X_child);
return

% Simulated Binary Crossover (SBX) operator
function [y1, y2] = op_SBX_matrix(l_limit,u_limit, x1, x2, eta)
y1 = x1;
y2 = x2;
ipos = find(abs(x1-x2) > 1e-6);
if ~isempty(ipos)
    x1_op = x1(ipos);
    x2_op = x2(ipos);
    l_op = l_limit(ipos);
    u_op = u_limit(ipos);
    pos_swap = x2_op < x1_op;
    tmp = x1_op(pos_swap);
    x1_op(pos_swap) = x2_op(pos_swap);
    x2_op(pos_swap) = tmp;
    r = rand(size(x1_op));
    beta = 1 + (2*(x1_op - l_op)./(x2_op - x1_op));
    alpha = 2 - beta.^-(eta+1);
    betaq = (1./(2-r.*alpha)).^(1/(eta+1));
    betaq(r <= 1./alpha) = (r(r <= 1./alpha).*alpha(r <= 1./alpha)).^(1/(eta+1));
    y1_op = 0.5 * (x1_op + x2_op - betaq.*(x2_op - x1_op));
    
    beta = 1 + 2*(u_op - x2_op)./(x2_op - x1_op);
    alpha = 2 - beta.^-(eta+1);
    betaq = (1./(2-r.*alpha)).^(1/(eta+1));
    betaq(r <= 1./alpha) = (r(r <= 1./alpha).*alpha(r <= 1./alpha)).^(1/(eta+1));
    y2_op = 0.5 * (x1_op + x2_op + betaq.*(x2_op - x1_op));
    
    y1_op(y1_op < l_op) = l_op(y1_op < l_op);
    y1_op(y1_op > u_op) = u_op(y1_op > u_op);
    
    y2_op(y2_op < l_op) = l_op(y2_op < l_op);
    y2_op(y2_op > u_op) = u_op(y2_op > u_op);
    
    pos_swap = (rand(size(x1_op)) <= 0.5);
    tmp = y1_op(pos_swap);
    y1_op(pos_swap) = y2_op(pos_swap);
    y2_op(pos_swap) = tmp;
    
    y1(ipos) = y1_op;
    y2(ipos) = y2_op;
end
return

function [c, fn_evals] = crossover_SBX_matrix(LB,UB,def,prob,p)
eta=def.distribution_mutation;
c = p; % parent size = no_solution*no_variable.
fn_evals = 0;
A = rand(size(p,1)/2,1);
is_crossover =[(A <= def.prob_crossover)';(A <= def.prob_crossover)'];
p_cross = p(is_crossover,:);
[N,~] = size(p_cross);
c_cross = p_cross;
p1_cross = p_cross(1:2:N,:);
p2_cross = p_cross(2:2:N,:);
B = rand(size(p_cross,1)/2,prob.nx);
l_limit = repmat(LB,size(p_cross,1)/2,1);
u_limit = repmat(UB,size(p_cross,1)/2,1);
cross_pos = (B <= 0.5);
l_cross = l_limit(cross_pos);
u_cross = u_limit(cross_pos);
p1 = p1_cross(cross_pos);
p2 = p2_cross(cross_pos);
c1 = p1_cross;
c2 = p2_cross;
[y1, y2] = op_SBX_matrix(l_cross,u_cross,p1,p2,eta);
c1(cross_pos) = y1;
c2(cross_pos) = y2;
c_cross(1:2:N,:) = c1;
c_cross(2:2:N,:) = c2;
c(is_crossover,:) = c_cross;
return

% Polynomial mutation operator: Matrix Form
function [x] = op_POLY_matrix(LB,UB,x,def)
def.distribution_mutation;
x_min = LB;
x_max = UB;
pos_mu = find(x_max > x_min);
if ~isempty(pos_mu)
    x_mu = x(pos_mu);
    x_min_mu = x_min(pos_mu);
    x_max_mu = x_max(pos_mu);
    delta1 = (x_mu - x_min_mu)./(x_max_mu - x_min_mu);
    delta2 = (x_max_mu - x_mu)./(x_max_mu - x_min_mu);
    mut_pow = 1/(def.distribution_mutation+1);
    rand_mu = rand(size(delta2));
    xy = 1 - delta2;
    val = 2*(1 - rand_mu) + 2*(rand_mu - 0.5).*xy.^(def.distribution_mutation+1);
    deltaq = 1 - val.^mut_pow;
    xy(rand_mu <= 0.5) = 1 - delta1(rand_mu <= 0.5);
    val(rand_mu <= 0.5) = 2*rand_mu(rand_mu <= 0.5) + (1-2*rand_mu(rand_mu <= 0.5)).* xy(rand_mu <= 0.5).^(def.distribution_mutation+1);
    deltaq(rand_mu <= 0.5) = val(rand_mu <= 0.5).^mut_pow - 1;
    
    x_mu = x_mu + deltaq.*(x_max_mu - x_min_mu);
    x_mu(x_mu < x_min_mu) = x_min_mu(x_mu < x_min_mu);
    x_mu(x_mu > x_max_mu) = x_max_mu(x_mu > x_max_mu);
    
    x(pos_mu) = x_mu;
end
return

function [p, fn_evals] = mutation_POLY_matrix(LB,UB,def,prob, p)
fn_evals = 0;
A = rand(size(p,1),prob.nx);
l_limit = repmat(LB,size(p,1),1);
u_limit = repmat(UB,size(p,1),1);
p_mut = p(A <= def.prob_mutation);
l_mut = l_limit(A <= def.prob_mutation);
u_mut = u_limit(A <= def.prob_mutation);
p_mut = op_POLY_matrix(l_mut,u_mut,p_mut,def);
p(A <= def.prob_mutation) = p_mut;
return
