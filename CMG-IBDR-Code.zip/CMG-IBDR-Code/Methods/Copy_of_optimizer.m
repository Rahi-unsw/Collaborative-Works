%% Multi-objective memetic algorithm
function optimizer(k)
MaxEval = 1e5;
% Offspring generation scheme and parameters
param.flag = 1; % 1 for single-objective 2 for multi-objective 
param.prob_crossover = 1;
param.prob_mutation = 0.1;
param.distribution_crossover = 20;
param.distribution_mutation = 20;
param.popsize = 100;
Select_testbed = 2;
DB  = Select_testbed;
[caseStudyData, DB_name] = callDatabase(DB);
otherParameters = setOtherParameters(caseStudyData,param.popsize,Select_testbed);
otherParameters.one = setOtherParameters(caseStudyData,1,Select_testbed);
otherParameters.iRuns = k;
rand('state',otherParameters.iRuns)
[LB,UB] = setVariablesBounds(caseStudyData,otherParameters, Select_testbed);
prob.bounds(:,1) = LB';prob.bounds(:,2) = UB';prob.nx = 940;cast_var = (1:60);
% Population initialization
pop.x = repmat(LB,param.popsize,1)+repmat((UB-LB),param.popsize,1).*rand(param.popsize,prob.nx);
pop.x(:,cast_var) = round(pop.x(:,cast_var));
[a,b] = feval(otherParameters.fnc,pop.x,caseStudyData,otherParameters);
pop.f(:,1) = b.Fit;pop.f(:,2) = b.Penalty;
archive.x = pop.x;archive.f(:,1:2) = pop.f;archive.f(:,3) = a;
count = size(archive.x,1);CurrEval = count;
% Ranking 
if param.flag == 1
    [~,idf] = sort(archive.f(:,3));
else
    [id_fronts,~,~,~] = E_NDSort_c(pop.f(:,1:2));
    idf = [];
    for i = 1:length(id_fronts)
        idf = [idf;id_fronts{i}];
    end
end
pop.x = pop.x(idf,:);
pop.f = pop.f(idf,1:2);

% Main body
while CurrEval < MaxEval
    if count >= 50000
        [~,best_id] = min(archive.f(:,3));
        x = archive.x(best_id,:);
        [~,~,output,history,~] = runfmincon(x,LB,UB,prob,caseStudyData,otherParameters);
        x_local = history.x;MaxEval = MaxEval - size(history.x,1);
        x_local(:,cast_var) = round(x_local(:,cast_var));
        [f1,f2] = feval(otherParameters.fnc,x_local,caseStudyData,otherParameters);
        archive.x = [archive.x;x_local];archive.f = [archive.f;f2.Fit,f2.Penalty,f1];
        count = 0;
        CurrEval = CurrEval + output.funcCount;
    else
        child.f = [];
        id = min([randperm(size(pop.x,1))' randperm(size(pop.x,1))'],[],2);
        pop.x = pop.x(id,:);
        if mod(size(pop.x,1),2) == 0
            child.x = Generate_child_SBX_PM(pop,prob,param);
        else
            xx = repmat(LB,1,1)+repmat((UB-LB),1,1).*rand(1,prob.nx);
            pop.x = [pop.x;xx];
            child.x = Generate_child_SBX_PM(pop,prob,param);
            child.x(end,:) = [];
        end
        child.x(:,cast_var) = round(child.x(:,cast_var));
        [c,d] = feval(otherParameters.fnc,child.x,caseStudyData,otherParameters);
        child.f(:,1) = d.Fit;child.f(:,2) = d.Penalty;
        archive.x = [archive.x;child.x];archive.f = [archive.f;child.f,c];
        count = count + size(child.x,1);
        CurrEval = CurrEval + size(child.x,1);
    end
    [un_archive.x,un_id] = unique(archive.x,'rows','stable');
    un_archive.f = archive.f(un_id,:);
    if param.flag == 1
        [~,idf] = sort(un_archive.f(:,3));
    else
        [id_fronts,~,~,~] = E_NDSort_c(un_archive.f(:,1:2));
        idf = [];
        for i = 1:length(id_fronts)
            idf = [idf;id_fronts{i}];
        end
    end
    if (MaxEval-CurrEval) >= param.popsize
        N = param.popsize;
    else
        N = MaxEval-CurrEval;
    end
    pop.x = un_archive.x(idf(1:N),:);
    pop.f = un_archive.f(idf(1:N),1:2);
    [~,tmp_id] = min(archive.f(:,3));
    disp([k CurrEval archive.f(tmp_id,:)]);
end
best.x = archive.x(tmp_id,:);best.f = archive.f(tmp_id,:);
save(strcat('Best_Result_Run_',num2str(k),'.mat'),'best');
save(strcat('Archive_Result_Run_',num2str(k),'.mat'),'archive');
return
