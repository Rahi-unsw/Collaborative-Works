
% This function measures the T1 and T2 metric for each solution
function [T1_measure,T2_measure,T1,T2]=sol_measures(x,f,perc_frac,LB,UB,ideal,nadir)

nsol=size(x,1);
nvar=size(x,2);
nobj=size(f,2);

% Solid diagonal diatance in x and f space
sdx=sqrt(nvar);
sdf=sqrt(nobj);

% Cutoffs for x
cutx=sdx*perc_frac/100;
cutf=sdf*perc_frac/100;

% Normalization of x wrt UB and LB
nx=(x-repmat(LB,nsol,1))./repmat(UB-LB,nsol,1);
% Normalization of f wrt ideal and nadir
nf=(f-repmat(ideal,nsol,1))./repmat(nadir-ideal,nsol,1);
% Pairwise diatance between solutions in normalized x space
dx=squareform(pdist(nx));
% Pairwise diatance between solutions in normalized f space
df=squareform(pdist(nf));

for i=1:length(perc_frac)
    % No of elements that are common : For T1 measure
    ix1=(df<=cutf(i));
    ix2=(dx<=cutx(i));
    cc=ix1+ix2;
    cc(cc==1)=0;
    cc(cc==2)=1;
    T1(:,i)=sum(cc,2)-1;
    % No of elements that are close in f but far in x
    ix3=(dx>cutx(i));
    ff=ix1+ix3;
    ff(ff==1)=0;
    ff(ff==2)=1;
    T2(:,i)=sum(ff,2);
end
% The T1 measure
T1_measure=sum(T1,2);
tmp=cumsum(T2,2);
T2_measure=tmp(:,end);

return

