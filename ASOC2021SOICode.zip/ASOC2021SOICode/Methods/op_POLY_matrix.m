
% Polynomial mutation operator: Matrix Form
function [x] = op_POLY_matrix(LB,UB,x,def)
def.distribution_mutation;
x_min = LB;
x_max = UB;
pos_mu = find(x_max > x_min);
if ~isempty(pos_mu)
    x_mu = x(pos_mu);
    x_min_mu = x_min(pos_mu);
    x_max_mu = x_max(pos_mu);
    delta1 = (x_mu - x_min_mu)./(x_max_mu - x_min_mu);
    delta2 = (x_max_mu - x_mu)./(x_max_mu - x_min_mu);
    mut_pow = 1/(def.distribution_mutation+1);
    rand_mu = rand(size(delta2));
    xy = 1 - delta2;
    val = 2*(1 - rand_mu) + 2*(rand_mu - 0.5).*xy.^(def.distribution_mutation+1);
    deltaq = 1 - val.^mut_pow;
    xy(rand_mu <= 0.5) = 1 - delta1(rand_mu <= 0.5);
    val(rand_mu <= 0.5) = 2*rand_mu(rand_mu <= 0.5) + (1-2*rand_mu(rand_mu <= 0.5)).* xy(rand_mu <= 0.5).^(def.distribution_mutation+1);
    deltaq(rand_mu <= 0.5) = val(rand_mu <= 0.5).^mut_pow - 1;
    
    x_mu = x_mu + deltaq.*(x_max_mu - x_min_mu);
    x_mu(x_mu < x_min_mu) = x_min_mu(x_mu < x_min_mu);
    x_mu(x_mu > x_max_mu) = x_max_mu(x_mu > x_max_mu);
    
    x(pos_mu) = x_mu;
end
return
