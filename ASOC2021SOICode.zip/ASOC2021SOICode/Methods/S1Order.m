%% Ordering for Scenario-I
function [order,SOIs,ideal,nadir,id_fronts] = S1Order(f,param)
%% Setting the normalization bounds
[ideal,nadir,~,id_fronts] = NormalizationBounds(f,param.spacing);
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);

%% nSOI identification
nd_ids = id_fronts{1};
fn_norm = f_norm(nd_ids,:);
if length(nd_ids) >= param.nSOI
    L1 = ones(size(fn_norm,1),size(fn_norm,2))-fn_norm;
    tmp_ids = find(sum(L1<0,2)~=0);
    deleted_ids = nd_ids(tmp_ids);
    new_nd = setdiff(nd_ids,deleted_ids,'stable');
    if length(new_nd) >= param.nSOI
        fnn_norm = f_norm(new_nd,:);
        asf = sum(ones(size(fnn_norm,1),size(fnn_norm,2))-fnn_norm,2);
        L1_normalized = (asf - min(asf))./(max(asf)-min(asf));
        g_m = (ones(size(fnn_norm,1),size(fnn_norm,2))-fnn_norm);
        w_m = g_m./repmat(sum(g_m,2),1,size(fnn_norm,2));
        [ThetaInDegrees,Order] = neighbors(w_m);
        for i = 1:size(fnn_norm,1)
            difference_asf = repmat(L1_normalized(i),size(fnn_norm,1),1)-L1_normalized(Order(i,:));
            id = find(difference_asf<0,1);
            if isempty(id)
                knee_angle(i)= max(ThetaInDegrees(i,:));
            end
            if (id==1)
                knee_angle(i) = 0;
            end
            if (id>1)
                knee_angle(i) = ThetaInDegrees(i,id-1);
            end
        end
        phi = knee_angle';
        phi_norm = (phi-min(phi))./(max(phi)-min(phi));
        [~,sid] = sort(phi_norm,'descend');
        SOIs = new_nd(sid(1:param.nSOI)); % SOI based on sorted (descending) phi measure
    else
        knee_id = new_nd;
        count = 2;
        while length(knee_id) < param.nSOI
            anchor_pts = f_norm(knee_id,:);
            tmp_id = id_fronts{count};
            tmp = f_norm(tmp_id,:);
            d = [];
            for i = 1:size(tmp,1)
                d(i) = min(sqrt(sum((repmat(tmp(i,:),length(knee_id),1) - anchor_pts).^2,2)));
            end
            [~,id] = sort(d,'descend');
            or1 = tmp_id(id);
            N = (param.nSOI - length(knee_id));
            if length(or1) >= N
                knee_id = [knee_id;or1(1:N)];
            else
                knee_id = [knee_id;or1];
            end
            count = count + 1;
        end
        SOIs = knee_id; % SOI based on normalized ED front by front with sparse selection
    end
else
    knee_id = nd_ids;
    count = 2;
    while length(knee_id) < param.nSOI
        anchor_pts = f_norm(knee_id,:);
        tmp_id = id_fronts{count};
        tmp = f_norm(tmp_id,:);
        d = [];
        for i = 1:size(tmp,1)
            d(i) = min(sqrt(sum((repmat(tmp(i,:),length(knee_id),1) - anchor_pts).^2,2)));
        end
        [~,id] = sort(d,'descend');
        or1 = tmp_id(id);
        N = (param.nSOI - length(knee_id));
        if length(or1) >= N
            knee_id = [knee_id;or1(1:N)];
        else
            knee_id = [knee_id;or1];
        end
        count = count + 1;
    end
    SOIs = knee_id; % SOI based on normalized ED front by front with sparse selection
end

%% Extreme ids
extreme_id = nd_ids(1:min(length(nd_ids),size(f,2)));

%% Ordering based on proximity
fSOI = f_norm(SOIs,:);
distances = (1./sqrt(size(f,2)))*pdist2(f_norm,fSOI);
top_id = [SOIs;extreme_id];
front1_id = setdiff(nd_ids,top_id);
dist = distances(front1_id,:);
front_dist = min(dist,[],2);
[~,tt2] = sort(front_dist,'ascend');
order1 = [top_id;front1_id(tt2)];
% Others are sorted based on ED from SOI
idfo = setdiff(1:size(f,1),order1);
min_dist = min(distances,[],2);
[~,t2] = sort(min_dist(idfo),'ascend');
order = [order1;idfo(t2)'];
order = unique(order,'stable');
order = order(1:size(f,1));
return