%% Order based on L1 and T measure
function [SOIs,LT_nd] = LT_SOI(f,def)
% [ideal,nadir,ndset,id_fronts] = NormalizationBounds(f,99);
[id_fronts,~,~,~] = E_NDSort_c(f);
f_norm = f;
% % Normalization
% f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);

% Sparse selection
all_ids = cell2mat(id_fronts);
id_frontone = id_fronts{1};
if (length(id_fronts{1}) >= def.nSOI)
    nd_norm = f_norm(id_frontone,:);
    [~,or1] = Choose_grid_set(nd_norm,def.nSOI);
    anchor_id = all_ids(or1);
else
    anchor_id = id_frontone;
    count = 2;
    while length(anchor_id) < def.nSOI
        anchor_pts = f_norm(anchor_id,:);
        tmp_id = id_fronts{count};
        tmp = f_norm(tmp_id,:);
        d = [];
        for i = 1:size(tmp,1)
            d(i) = min(sqrt(sum((repmat(tmp(i,:),length(anchor_id),1) - anchor_pts).^2,2)));
        end
        [~,id] = sort(d,'descend');
        or1 = tmp_id(id);
        N = (def.nSOI - length(anchor_id));
        if length(or1) >= N
            anchor_id = [anchor_id;or1(1:N)];
        else
            anchor_id = [anchor_id;or1];
        end
        count = count + 1;
    end
end
SOIs = anchor_id;
LT_nd = id_fronts;
return