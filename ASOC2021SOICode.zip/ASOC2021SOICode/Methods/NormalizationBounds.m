%% Setting the normalization bounds
function [ideal,nadir,fnd,id_fronts] = NormalizationBounds(f,spacing)
% Normalization
[id_fronts,~,~,~] = E_NDSort_c(f);
fnd = f(id_fronts{1},:);
% Finding ND set and ideal, nadir point
ids = 0;count = 1;tmp_fnd = [];
while ~isempty(ids)
    tmp_fnd = [tmp_fnd;f(id_fronts{count},:)];
    ideal = min(tmp_fnd,[],1);nadir = max(tmp_fnd,[],1);
    dif = abs(nadir-ideal);
    ids = find(dif <= 1e-4);
    count = count + 1;
end

% DRS removal
f_norm = (fnd-repmat(ideal,size(fnd,1),1))./repmat(nadir-ideal,size(fnd,1),1);
w = direction_vector(size(fnd,2),spacing);
for i = 1:size(f_norm,1)
    u = f_norm(i,:);
    uu = repmat(u,size(w,1),1);
    vv = w;
    normuu = vecnorm(uu,2,2);
    normvv = vecnorm(vv,2,2);
    costheta = dot(uu,vv,2)./(normuu.*normvv);
    ThetaInDegrees = real(acosd(costheta))';
    [~,wid(i)] = min(ThetaInDegrees);
end

% Axial direction vectors
[a,~] = find(w == 0);nvectorall = [];
for i = 1:length(a)
    spop = find(wid == a(i));
    if ~isempty(spop)
        id = find(w(a(i),:) > 0);
        ttmp = fnd(spop,:);
        tmp = f_norm(spop,id);
        tmp2 = sum(tmp.*tmp,2);
        [~,id2] = min(tmp2);
        nvector = zeros(1,size(w,2));
        nvector(id) = ttmp(id2,id);
        nvectorall = [nvectorall;nvector];
    end
end
nadir_n = max(nvectorall,[],1);
dif = abs(nadir_n-ideal);
ids = find(dif <= 1e-4);
if isempty(ids)
   nadir = nadir_n; 
end
return