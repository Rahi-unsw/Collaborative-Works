%% Check Offspring Population is unique or not
function [v_X_child] = valid_offspring(X_child,Archive,def,prob,LB,UB)
X_pop = Archive(:,1:prob.nx);
if ~isempty(X_child)
    X_child_nor = (X_child-repmat(LB,size(X_child,1),1))./repmat((UB-LB),size(X_child,1),1); % precision limit upto 5 digit with normalized solution
    X_child_r = round(X_child_nor,5);
    X_pop_nor = (X_pop-repmat(LB,size(X_pop,1),1))./repmat((UB-LB),size(X_pop,1),1);
    X_pop_r = round(X_pop_nor,5);
    [a,aid] = unique(X_child_r,'rows','stable');
    [b,b_id] = setdiff(a,X_pop_r,'rows','stable');
    if size(b,1)~=size(X_child,1)
        X_child_n = X_child(aid(b_id),:);
        N = def.pop_size - size(X_child_n,1);
        new_pop = repmat(LB,N,1)+repmat((UB-LB),N,1).*lhsdesign(N,prob.nx);
        v_X_child = [X_child_n;new_pop];
    else
        v_X_child = X_child;
    end
else
    v_X_child = [];
end
return







