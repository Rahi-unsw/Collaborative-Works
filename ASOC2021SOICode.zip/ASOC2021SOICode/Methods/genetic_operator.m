%% Simulated binary crossover and polynomial mutation
function [X_child] = genetic_operator(LB,UB,def,prob,X_parent_ordered)
[X_child] = crossover_SBX_matrix(LB,UB,def,prob,X_parent_ordered);
[X_child] = mutation_POLY_matrix(LB,UB,def,prob,X_child);
return
