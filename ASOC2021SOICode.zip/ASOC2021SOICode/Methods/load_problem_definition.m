%% Load the problem specifications
function [prob]=load_problem_definition(def)
funh=str2func(def.problem_name);
prob=funh(def.nf);
return

