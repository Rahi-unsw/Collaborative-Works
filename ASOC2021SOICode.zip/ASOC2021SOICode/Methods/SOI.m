function [knee_f,knee_id,deleted_ids,phi_measure] = SOI(ideal,nadir,f,nSOI)
% Rescaling based on DRS removal
f_norm=(f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);

% Removing data beyond nadir
d = ones(size(f_norm,1),size(f_norm,2))-f_norm;
deleted_ids = find(sum(d<0,2)~=0);
f_norm(deleted_ids,:)=[];
asf=sum(ones(size(f_norm,1),size(f_norm,2))-f_norm,2);
g_m=(ones(size(f_norm,1),size(f_norm,2))-f_norm);
w_m=g_m./repmat(sum(g_m,2),1,size(f_norm,2));
[ThetaInDegrees,Order]=neighbors(w_m);
knee_L1=sum(abs(ones(size(f_norm,1),size(f_norm,2))-f_norm),2);
for i=1:size(f_norm,1)
    difference_asf=repmat(asf(i),size(f_norm,1),1)-asf(Order(i,:));
    id=find(difference_asf<0,1);
    if isempty(id)
%         knee_angle(i)=max(max(ThetaInDegrees)); 
        knee_angle(i)= max(ThetaInDegrees(i,:));
    end
    if(id==1)
        knee_angle(i)=0;
    end
    if(id>1)
        knee_angle(i)=ThetaInDegrees(i,id-1);
    end
end
knee_angle = knee_angle';phi_measure = knee_angle';
store = [-knee_angle -knee_L1 ];
[id_fronts,~,~,~] = E_NDSort_c(store);

% DSS
all_ids = cell2mat(id_fronts);
id_frontone = id_fronts{1};
if (length(id_fronts{1}) >= nSOI)
    nd_norm = f_norm(id_frontone,:);
    [~,or1] = Choose_grid_set(nd_norm,nSOI);
    knee_id = all_ids(or1);
else
    knee_id = id_frontone;
    count = 2;
    while length(knee_id) < nSOI
        anchor_pts = f_norm(knee_id,:);
        tmp_id = id_fronts{count};
        tmp = f_norm(tmp_id,:);
        d = [];
        for i = 1:size(tmp,1)
            d(i) = min(sqrt(sum((repmat(tmp(i,:),length(knee_id),1) - anchor_pts).^2,2)));
        end
        [~,id] = sort(d,'descend');
        or1 = tmp_id(id);
        N = (nSOI - length(knee_id));
        if length(or1) >= N
            knee_id = [knee_id;or1(1:N)];
        else
            knee_id = [knee_id;or1];
        end
        count = count + 1;
    end
end
knee_f = f_norm(knee_id,:);
return