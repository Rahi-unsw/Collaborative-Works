%% Knee Ordering 
function [order,knee_id]=knee_order(f,knee_fn,ideal,nadir,id_fronts)
f_norm=(f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
knee=knee_fn;
distances=zeros(size(f,1),size(knee,1));
for i=1:size(knee,1)
    d=repmat(knee(i,:),size(f,1),1)-f_norm;
    tmp=(1./sqrt(size(f,2)))*sqrt(sum(d.^2,2));
    distances(:,i)=tmp;
end
idf1=id_fronts{1};
% Finding the knee ids
knee_id=[];
for i=1:size(knee,1)
    id=find(sum(abs(repmat(knee(i,:),size(f_norm,1),1)-f_norm),2)==0);
    knee_id=[knee_id id'];
end

top_id=[knee_id'];
front1_id=setdiff(idf1,top_id);
dist=distances(front1_id,:);
front_dist=min(dist,[],2);
[~,tt2]=sort(front_dist,'ascend');
order1=[top_id;front1_id(tt2)];
% Others are sorted based on ED from Knee
idfo=setdiff(1:size(f,1),idf1);
min_dist=min(distances,[],2);
[~,t2]=sort(min_dist(idfo),'ascend');
order=[order1 ;idfo(t2)'];
order=order(1:size(f,1));
return