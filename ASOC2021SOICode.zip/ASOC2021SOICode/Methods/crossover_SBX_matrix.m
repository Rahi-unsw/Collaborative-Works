
function [c, fn_evals] = crossover_SBX_matrix(LB,UB,def,prob,p)
eta=def.distribution_mutation;
c = p; % parent size = no_solution*no_variable.
fn_evals = 0;
A = rand(size(p,1)/2,1);
is_crossover =[(A <= def.prob_crossover)';(A <= def.prob_crossover)'];
p_cross = p(is_crossover,:);
[N,m] = size(p_cross);
c_cross = p_cross;
p1_cross = p_cross(1:2:N,:);
p2_cross = p_cross(2:2:N,:);
B = rand(size(p_cross,1)/2,prob.nx);
l_limit = repmat(LB,size(p_cross,1)/2,1);
u_limit = repmat(UB,size(p_cross,1)/2,1);
cross_pos = (B <= 0.5);
l_cross = l_limit(cross_pos);
u_cross = u_limit(cross_pos);
p1 = p1_cross(cross_pos);
p2 = p2_cross(cross_pos);
c1 = p1_cross;
c2 = p2_cross;
[y1, y2] = op_SBX_matrix(l_cross,u_cross,p1,p2,eta);
c1(cross_pos) = y1;
c2(cross_pos) = y2;
c_cross(1:2:N,:) = c1;
c_cross(2:2:N,:) = c2;
c(is_crossover,:) = c_cross;
return
