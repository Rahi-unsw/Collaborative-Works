
function [p, fn_evals] = mutation_POLY_matrix(LB,UB,def,prob, p)
fn_evals = 0;
A = rand(size(p,1),prob.nx);
l_limit = repmat(LB,size(p,1),1);
u_limit = repmat(UB,size(p,1),1);
p_mut = p(A <= def.prob_mutation);
l_mut = l_limit(A <= def.prob_mutation);
u_mut = u_limit(A <= def.prob_mutation);
p_mut = op_POLY_matrix(l_mut,u_mut,p_mut,def);
p(A <= def.prob_mutation) = p_mut;
return
