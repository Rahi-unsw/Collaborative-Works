% This function measures the proximity solutions around the knee points
function [proximity_solns]=proximity_sol(knee_f,f,perc_frac,ideal,nadir)

nsol=size(f,1);
nobj=size(f,2);

% Solid diagonal diatance f space
sdf=sqrt(nobj);

% Cutoffs for x
cutf=sdf*perc_frac/100;

% Normalization of f wrt ideal and nadir
nf=(f-repmat(ideal,nsol,1))./repmat(nadir-ideal,nsol,1);
knee_nf=(knee_f-repmat(ideal,size(knee_f,1),1))./repmat(nadir-ideal,size(knee_f,1),1);
id=find(abs(sum((knee_nf-nf),2))==0);
% Pairwise diatance between solutions in normalized f space
df=squareform(pdist(nf));

ix=[];proximity_solns=cell(length(id),length(perc_frac));
for i=1:length(id)
    for j=1:length(perc_frac)
        ix1=find(df(id(i),:)<=cutf(j));
        ix2=setdiff(ix1,ix);
        proximity_solns{i,j}=ix2;
        ix=ix1;
    end
end

return

