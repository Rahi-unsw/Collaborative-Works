function [ThetaInDegrees,Order]=neighbors(w)
w_uv=w./repmat(sqrt(sum(w.^2,2)),[1,size(w,2)]);
angle=real(acosd(w_uv*w_uv'));
[theta,Order]=sort(angle,2);
ThetaInDegrees=theta;
% ThetaInDegrees=(round(theta*1e6))*1e-6;
return

