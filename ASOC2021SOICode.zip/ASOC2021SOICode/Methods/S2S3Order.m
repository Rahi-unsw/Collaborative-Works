%% Ordering for Scenario-II and Scenario-III
function [order,SOIs,TL,ideal,nadir,id_fronts,LT_nd] = S2S3Order(x,f,param,prob)
%% Setting the normalization bounds
[ideal,nadir,~,id_fronts] = NormalizationBounds(f,param.spacing);
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
nd_ids = id_fronts{1};

%% nSOI identification
L1 = ones(size(f_norm,1),size(f_norm,2))-f_norm;
L1(L1<0) = 0;L1_norm = sum(abs(L1),2);
NL1 = (L1_norm-min(L1_norm))./(max(L1_norm)-min(L1_norm));
[order1,order2,~,~] = sol_measures(x,f,param.perc_frac,prob.range(:,1)',prob.range(:,2)',ideal,nadir);
% [order1,order2,~,~] = sol_measures(x(nd_ids,:),f(nd_ids,:),param.perc_frac,prob.range(:,1)',prob.range(:,2)',ideal,nadir);
if (param.type == 1)
    T_measure = (order1-min(order1))./(max(order1)-min(order1));
else
    T_measure = (order2-min(order2))./(max(order2)-min(order2));
end

% SOI identification from the ND in original f space
LT_measure = [-T_measure(nd_ids,:) -NL1(nd_ids,:)];
[SOIs,LT_nd] = LT_SOI(LT_measure,param);
SOIs = nd_ids(SOIs);LT_nd = nd_ids(LT_nd{1});
TL = [T_measure NL1];

%% Extreme ids
extreme_id = nd_ids(1:min(length(nd_ids),size(f,2)));

%% Ordering based on proximity
fSOI = f_norm(SOIs,:);
distances = (1./sqrt(size(f,2)))*pdist2(f_norm,fSOI);
top_id = [SOIs;extreme_id];
front1_id = setdiff(nd_ids,top_id);
dist = distances(front1_id,:);
front_dist = min(dist,[],2);
[~,tt2] = sort(front_dist,'ascend');
order1 = [top_id;front1_id(tt2)];
% Others are sorted based on ED from SOI
idfo = setdiff(1:size(f,1),order1);
min_dist = min(distances,[],2);
[~,t2] = sort(min_dist(idfo),'ascend');
order = [order1;idfo(t2)'];
order = unique(order,'stable');
order = order(1:size(f,1));
return