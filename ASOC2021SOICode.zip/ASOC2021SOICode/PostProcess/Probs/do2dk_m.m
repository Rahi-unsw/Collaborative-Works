function [f,g,x] = do2dk_m(objnum,x)
if nargin == 1
    prob.nx = 1; %30
    prob.nf = objnum; %2
    prob.ng = 0;
    for i = 1:prob.nx
        prob.range(i,:) = [0,1];
    end
    f = prob;
else
    [f,g,x] = do2dk_m_true(x,objnum);
end
end


function [f,g,x] = do2dk_m_true(x,objnum)
K = 4; % This parameter needs to be specified
s = 1; % Skewness parameter needs to be specified
num = size(x,2);
summ = 0;%sum(x(:,2:num),2);
g1 = 1 + 0;%round(9/(num-1))*summ;
r = 5 + 10*(x(:,1) - 0.5).^2+2^(s/2)/K * cos(2*K*pi*x(:,1));
f(:,1) = g1.*r.*(sin(pi*x(:,1)/2^(s+1) + pi*(1 + (2^s-1)/2^(s+2)))+1);
f(:,objnum) = g1.*r.*(cos(pi*x(:,1)/2 + pi)+1);
g = [];
end
