function DRS_illustration
clear all;clc;close all;
startup;
problem_name = 'deb3dk1_mm'; 
objnum = 3;
funh1 = str2func(problem_name);
prob1 = funh1(objnum);
[v1,v2] = meshgrid(0:.02:1,0:.02:1);
xx = [reshape(v1,size(v1,1)*size(v1,2),1) reshape(v2,size(v2,1)*size(v2,2),1)];
func = str2func(problem_name);
[ff,~] = func(prob1.nf,xx); % objective values
[fronts,~,~,~] = E_NDSort_c(ff);
fnd = ff(fronts{1},:);
nnd = setdiff((1:size(ff,1))',fronts{1}','stable');
fnnd = ff(nnd,:);
ideal = min(fnd);nadir = max(fnd);[~,nid] = max(fnd(:,3));
extreme = max(ff);[~,eid] = max(ff(:,3));
% Normalization based on ND
ff_norm = (ff-repmat(ideal,size(ff,1),1))./repmat(nadir-ideal,size(ff,1),1);
L1 = ones(size(ff_norm,1),size(ff_norm,2))-ff_norm;L1(L1<0) = 0;L1_norm = sum(abs(L1),2);
id_norm = find(L1_norm == max(L1_norm));
% Normalization basede on extreme
ff_ex = (ff-repmat(ideal,size(ff,1),1))./repmat(extreme-ideal,size(ff,1),1);
L1 = ones(size(ff_norm,1),size(ff_norm,2))-ff_ex;L1(L1<0) = 0;L1_ex = sum(abs(L1),2);
id_ex = find(L1_ex == max(L1_ex));


figure;
plot3(fnd(:,1),fnd(:,2),fnd(:,3),'g.');hold on;
plot3(fnnd(:,1),fnnd(:,2),fnnd(:,3),'r.');
plot3(ff(fronts{1}(nid),1),ff(fronts{1}(nid),2),ff(fronts{1}(nid),3),'bp','MarkerSize',15,'MarkerFaceColor','b','MarkerEdgeColor','b');
plot3(ff(eid,1),ff(eid,2),ff(eid,3),'kp','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k');
box on;ax=gca;ax.BoxStyle = 'full';view(54,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
xlim([0 10]);ylim([0 10]);zlim([0 15]);
% [~, h] = legend([p1,p2],{'ND solutions','Dom. solutions'},'Orientation','horizontal','location','NorthOutside','fontsize',15);
% objhl = findobj(h, 'type', 'line');
set(gca,'fontsize',15);%set(objhl,'Markersize',25);
annotation('textarrow',[0.307142857142857 0.148214285714286],[0.826190476190476 0.821428571428572],'String',{'Worst DRS solution in f_3'},'FontSize',15);
annotation('textarrow',[0.498214285714286 0.146428571428571],[0.650000000000002 0.657142857142859],'String',{'DRS solutions'},'FontSize',15);
annotation('textarrow',[0.371428571428571 0.151785714285714],[0.511904761904762 0.497619047619048],'String',{'Maximum f_3 value of true ND'},'FontSize',15);
filename = strcat(problem_name,'_DRS_solutions');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot3(fnd(:,1),fnd(:,2),fnd(:,3),'g.');hold on;
plot3(ff(id_norm,1),ff(id_norm,2),ff(id_norm,3),'ro','MarkerSize',15,'MarkerFaceColor','b','MarkerEdgeColor','b');
plot3(ff(id_ex,1),ff(id_ex,2),ff(id_ex,3),'ko','MarkerSize',15,'MarkerFaceColor','k','MarkerEdgeColor','k');
box on;ax=gca;ax.BoxStyle = 'full';view(54,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
xlim([0 10]);ylim([0 10]);zlim([0 15]);
set(gca,'fontsize',15);
set(gca,'fontsize',15);%set(objhl,'Markersize',25);
annotation('textarrow',[0.366071428571429 0.266071428571429],[0.445238095238095 0.347619047619048],...
    'String',{'Correct SOI with DRS removal'},'FontSize',15);
annotation('textarrow',[0.235714285714286 0.148214285714286],[0.595238095238095 0.516666666666667],...
    'String',{'Incorrect SOI in presence of','worst DRS solution'},'FontSize',15);
filename = strcat(problem_name,'_SOI_selection_DRS_removal');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');
return