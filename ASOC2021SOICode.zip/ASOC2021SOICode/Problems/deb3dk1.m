function [f,g,x] = deb3dk1(objnum,x)
if nargin == 1
    prob.nx = 30;
    prob.nf = 3; %3
    prob.ng = 0;
    for i = 1:prob.nx
        prob.range(i,:) = [0,1];
    end
    f = prob;
else
    [f,g,x] = debndk_true(objnum,x);
end
end


function [f,g,x] = debndk_true(objnum,x)
K = 1; % This parameter needs to be specified
num = size(x,2);
summ = sum(x(:,2:num),2);
g1 = 1 + 9/(num-1)*summ; % it was rounded in the previous manuscript
r_i = 5+10*(x(:,1:objnum-1) - 0.5).^2+(objnum-1)/K * cos(2*K*pi*x(:,1:objnum-1));%;% +
r = sum(r_i,2)/(objnum-1);
tmp1 = prod(sin(pi*x(:,1:objnum-1)/2),2);
f(:,1) = g1.*r.*tmp1;
for i = 2:objnum-1
    tmp2 = prod(sin(pi*x(:,1:objnum-i)/2),2).*prod(cos(pi*x(:,objnum-i+1)/2),2);
    f(:,i) = g1.*r.*tmp2;
end
f(:,objnum) = g1.*r.*(cos(pi*x(:,1)/2));
g = [];
end