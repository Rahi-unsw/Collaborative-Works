%% Windturbine problem for multi-objective optimization
function [f,g,x] = Windturbine_MOP(objnum,x,path)
if nargin == 1
    prob.nf = 5;
    prob.ng = 22;
    prob.nx = 32;
    for i=1:4
        prob.range(i,:) = [1.0,5.3];
    end
    prob.range(5,:) = [0.1,0.3];
    for i=6:9
        prob.range(i,:) = [-5,30];
    end
    for i=10:19
        prob.range(i,:) = [0.005,0.2];
    end
    for i=20:22
        prob.range(i,:) = [-6.3,0.0];
    end
    prob.range(23,:) = [6.0,14.0];
    prob.range(24,:) = [6.0,20.0];
    prob.range(25,:) = [50,80];
    prob.range(26,:) = [20,70];
    for i=27:29
        prob.range(i,:) = [3.87,6.3];
    end
    for i=30:32
        prob.range(i,:) = [0.005,0.1];
    end
    f = prob;
else
    [f,g] = Windturbine_SOP_true(objnum,x,path);
end
return

function [f,g] = Windturbine_SOP_true(objnum,x,path)
% Please make sure that the MATLAB is started from within the activated ECComp2019 virtual environment.
% Write source ECComp2019/ECComp2019/bin/activate in the bash terminal.

cd(path);

save('pop_vars_eval.txt', 'x', '-ascii', '-double', '-tabs')

system(sprintf('python windturbine_SOP.py %s',path));

f(:,1:objnum) = textread('pop_objs_eval.txt');
[g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13,g14,g15,g16,g17,g18,g19,g20,g21,g22] = textread('pop_cons_eval.txt'); % ,[repmat('%20.20f',1,21),'%20.20f']);

g = [g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13,g14,g15,g16,g17,g18,g19,g20,g21,g22];
g = -1.*g;
return