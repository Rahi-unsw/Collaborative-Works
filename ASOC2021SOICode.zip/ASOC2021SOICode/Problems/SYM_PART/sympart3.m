function [f,g,x] = sympart3(objnum,x)
if nargin == 1
    prob.nx = 2;
    prob.nf = 2; 
    prob.ng = 0;
    for i = 1:prob.nx
        prob.range(i,:) = [-20,20];
    end
    f = prob;
else
    [f,g,x] = sympart3_true(x,objnum);
end
end


function [f,g,x] = sympart3_true(x,objnum)
a = 1;b = 10;c = 8;w = pi/4;eps = 1e-3;
% Transformation
x_1 = x(:,1).*(40./(x(:,2)-20+eps));
% Rotation
xx1 = cos(w).*x_1-sin(w).*x(:,2);
xx2 = sin(w).*x_1+cos(w).*x(:,2);
x(:,1) = xx1;
x(:,2) = xx2;
% Tile identifier
tmp1 = sign(x(:,1)).*ceil((abs(x(:,1))-(a+(c/2)))./((2*a)+c));
t1 = sign(tmp1).*min(abs(tmp1),1);
tmp2 = sign(x(:,2)).*ceil((abs(x(:,2))-(b/2))./b);
t2 = sign(tmp2).*min(abs(tmp2),1);

x1 = x(:,1)-(t1.*(c+2*a));
x2 = x(:,2)-(t2.*b);

% Objective functions
f(:,1) = (x1 + a).^2 + x2.^2;
f(:,objnum) = (x1 - a).^2 + x2.^2;
g = [];
end
