%% All illustrations in the revised manuscript
function illustration
clear all;clc;close all;
MoveFigure = 'Figures';
filename = mfilename;
motherfolderpath = which(filename);
motherfolder = fileparts(motherfolderpath);
cd(motherfolder);
addpath(genpath(motherfolder));

%% Manuscript theoretical figures: Figure 1 (for deb2dk4 problem given above)
% Problem specifications
problem_name = 'deb2dk4_m'; 
objnum = 2;
spacing = 99;nSOI = 2;

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);

% Evaluation
x = linspace(0,1,100)';
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values
[ideal,nadir,fnd,~] = NormalizationBounds(f,spacing);
f_norm = (fnd-repmat(ideal,size(fnd,1),1))./repmat(nadir-ideal,size(fnd,1),1);
L1 = sum(abs(ones(size(f_norm,1),size(f_norm,2))-f_norm),2);

% Knee id identification
[~,~,~,phi_measure] = SOI(ideal,nadir,fnd,nSOI);
[~,b] = sort(phi_measure,'descend');

figure;
scatter(f_norm(:,1),f_norm(:,2),10,L1);colorbar;hold on;
idsl = b(1:4);
for i=1:length(idsl)
  plot(f_norm(idsl(i),1),f_norm(idsl(i),2),'r.','MarkerSize',ceil((1.5*phi_measure(idsl(i)))/2)+10);hold on;
end
line([f_norm(43,1) 1],[f_norm(43,2) 1],'Color','black','LineStyle','--','LineWidth',1.2);
line([f_norm(44,1) 1],[f_norm(44,2) 1],'Color','black','LineStyle','--','LineWidth',1.2);
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('f_1 (normalized)');ylabel('f_2 (normalized)');
% legend('location','NorthEast');
annotation('arrow',[0.7875 0.646428571428571],...
    [0.921428571428571 0.304761904761905]);
annotation('arrow',[0.7875 0.491071428571429],...
    [0.923809523809524 0.457142857142857]);
annotation('arrow',[0.7875 0.3875],...
    [0.923809523809524 0.580952380952381]);
annotation('arrow',[0.783928571428571 0.253571428571429],...
    [0.921428571428571 0.75952380952381]);
set(gca,'fontsize',15);
filename = strcat('Fig1');
saveas(gcf,filename);
saveas(gcf,strcat(filename,'.jpg'));
print(filename,'-depsc2','-r300');


%% Manuscript theoretical figures: Figure 2 (for deb3dk1 problem)
% Problem specifications
problem_name = 'deb3dk1_m';
objnum = 3;
def.spacing = 21;def.nSOI = 1;

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
UB = prob.range(:,2)';LB = prob.range(:,1)'; % zeros
def.perc_frac = [10 20 30 40 50 60 70 80];

% Evaluation
[v1,v2] = meshgrid(0:.02:1,0:.02:1);
x = [reshape(v1,size(v1,1)*size(v1,2),1) reshape(v2,size(v2,1)*size(v2,2),1)];
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values
[~,knee_id,ideal,nadir,id_fronts] = S1Order(f,def);
id = id_fronts{1}; % non-dominated ids
domid = setdiff((1:length(x))',id); % dominated ids
xnd = (x(id,:));
xd = (x(domid,:));

% Knee id identification
knee_x = x(knee_id,:);
knee_fn  = f(knee_id,:);

% L1 norm and T1 and T2 measure of all data
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
L1 = ones(size(f_norm,1),size(f_norm,2))-f_norm;
L1(L1<0) = 0;
L1_norm = sum(abs(L1),2);
NL1 = (L1_norm-min(L1_norm))./(max(L1_norm)-min(L1_norm));
[T1_order,T2_order,T1_matrix,T2_matrix] = sol_measures(x,f,def.perc_frac,LB,UB,ideal,nadir);
add_order1 = (T1_order-min(T1_order))/(max(T1_order)-min(T1_order));
add_order2 = (T2_order-min(T2_order))/(max(T2_order)-min(T2_order));

% ND of L1 vs T1 and L1 vs T2
L1vsT1 = [-NL1 -add_order1];
L1vsT2 = [-NL1 -add_order2];
[id_fronts1,~,~,~] = E_NDSort_c(L1vsT1);
ND_L1vsT1 = id_fronts1{1}; 
[id_fronts2,~,~,~] = E_NDSort_c(L1vsT2);
ND_L1vsT2 = id_fronts2{1}; 

% Best L1 distribution (T1 measure) and Best L1 distribution (T2 measure)
BL1T1Dist = T1_matrix(ND_L1vsT1(1),:);
BL1T2Dist = T2_matrix(ND_L1vsT2(1),:);

% Figures
figure; % Figure 3(a): all x data (proximity plot)
radii = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]';
centers = repmat(knee_x,length(radii),1);
labels = {'Dom. Sol.','ND Sol.','SOI'};
plot(xd(:,1),xd(:,2),'.','Color',[0.9290 0.6940 0.1250],'MarkerSize',15);hold on;
plot(xnd(:,1),xnd(:,2),'b.','MarkerSize',15);
plot(knee_x(:,1),knee_x(:,2),'s','MarkerSize',15,'MarkerFaceColor','r');
viscircles(centers,radii,'Color','k');
box on;ax=gca;ax.BoxStyle = 'full';
xlim([0 1]);ylim([0 1]);
xlabel('x_1');ylabel('x_2');
legend(labels,'Orientation','horizontal','location','NorthOutside','FontSize',15);
set(gca,'fontsize',15);
filename = strcat(problem_name,'_proximity_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure; % Figure 3(b): all f data (proximity plot)
[proximity_solns] = proximity_sol(knee_fn,f,def.perc_frac,ideal,nadir);
nf=(f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
c = jet(length(def.perc_frac));
c = parula(length(def.perc_frac));
for i=1:length(def.perc_frac)
   sols_data=nf(proximity_solns{i},:);
   plot3(sols_data(:,1),sols_data(:,2),sols_data(:,3),'.','MarkerSize',10,'Color',c(i,:));hold on;
end
plot3(knee_fn(:,1),knee_fn(:,2),knee_fn(:,3),'s','MarkerSize',20,'MarkerFaceColor','r');
box on;ax=gca;ax.BoxStyle = 'full';view(132,12);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
xlim([0 max(nf(:,1))]);ylim([0 max(nf(:,2))]);zlim([0 max(nf(:,3))]);
[~, h] = legend(labels,'location','SouthEastOutside','FontSize',15);%'Orientation','horizontal',
objhl = findobj(h, 'type', 'line');
set(gca,'fontsize',15);set(objhl,'Markersize',25);
filename = strcat(problem_name,'_proximity_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 3(c): T1 measure of the best L1 solution
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
colormap('jet');
b = bar([BL1T1Dist;nan(1,length(BL1T1Dist))],'FaceColor','flat');
hAx=gca; % get a variable for the current axes handle
% str={'Distribution of sol'};
hAx.XTickLabel={}; % label the ticks
for k = 1:size(BL1T1Dist,2)
    b(k).CData = k;
end
xlim([0.4 1.6]);ylim([10 10000]);
ylabel('No. of solutions');
legend(labels,'location','SouthEastOutside');
set(gca,'YScale','log','fontsize',15);
filename = strcat(problem_name,'_Proximity_T1Distribution');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 3(d): T2 measure of the best L1 solution
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
colormap('jet');
b = bar([BL1T2Dist;nan(1,length(BL1T2Dist))],'FaceColor','flat');
hAx=gca; % get a variable for the current axes handle
% str={'T2 measure of the best L1 solution'};
hAx.XTickLabel={}; % label the ticks
for k = 1:size(BL1T2Dist,2)
    b(k).CData = k;
end
xlim([0.4 1.6]);ylim([10 10000]);
ylabel('No. of solutions');
legend(labels,'location','SouthEastOutside');
set(gca,'YScale','log','fontsize',15);
filename = strcat(problem_name,'_Proximity_T2Distribution');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


%% Manuscript SYM-PART figures: Figure 3-5 
sympart_illustration;


%% Manuscript theoretical figures: Figure 6 (for do2dk problem given above)
% Problem specifications
problem_name = 'do2dk_m'; 
objnum = 2;
def.spacing = 99;nSOI_all = [2];

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
UB = prob.range(:,2)';LB = prob.range(:,1)'; % zeros
def.perc_frac = [10 20 30 40 50 60 70 80];

% Evaluation
x = linspace(0,1,1000)';
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values

for i = 1:length(nSOI_all)
    def.nSOI = nSOI_all(i);
    % Knee id identification
    [order,SOIs,ideal,nadir,~] = S1Order(f,def);
    original_knee = f(SOIs,:);
    
    % L1 norm and T1 and T2 measure of all data
    def.type = 1;
    [ordert1,SOIT1,LT1,~,~,~,ND_L1vsT1] = S2S3Order(x,f,def,prob);
    def.type = 2;
    [ordert2,SOIT2,LT2,~,~,~,ND_L1vsT2] = S2S3Order(x,f,def,prob);
    [~,~,T1_matrix,T2_matrix] = sol_measures(x,f,def.perc_frac,LB,UB,ideal,nadir);
    
%     % Best L1 distribution (T1 measure) and Best L1 distribution (T2 measure)
%     BL1T1Dist = [T1_matrix(ND_L1vsT1(1),:);T1_matrix(ND_L1vsT1(2),:)];
%     BL1T2Dist = [T2_matrix(ND_L1vsT2(1),:);T2_matrix(ND_L1vsT2(2),:)];
%         
    % Figures
    figure; % Figure 6(a): 2 SOIs and ordered solutions for Scenario-I
    kn_order = f(order,:);
    scatter(kn_order(:,1),kn_order(:,2),10,(1:size(kn_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(original_knee(:,1),original_knee(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario1_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 6(b): 2 SOIs and ordered solutions for Scenario-II
    T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
    scatter(T1_order(:,1),T1_order(:,2),10,(1:size(T1_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(f(ND_L1vsT1,1),f(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T1(:,1),bestL1T1(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    if def.nSOI == 2
        annotation('textarrow',[0.364285714285714 0.276785714285714],[0.550000000000001 0.37857142857143],'String',{'Best L1 solution'},'FontSize',15);
        annotation('textarrow',[0.3875 0.341071428571428],[0.421428571428571 0.330952380952382],'String',{'Best T1 solution'},'FontSize',15);
    end
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario2_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 6(c): 2 SOIs and ordered solutions for Scenario-III
    T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
    scatter(T2_order(:,1),T2_order(:,2),10,(1:size(T2_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(f(ND_L1vsT2,1),f(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T2(:,1),bestL1T2(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    if def.nSOI == 2
        annotation('textarrow',[0.360714285714285 0.278571428571428],[0.513285714285715 0.371428571428572],'String',{'Best L1 solution'},'FontSize',15);
        annotation('textarrow',[0.4625 0.380357142857143],[0.401380952380953 0.259523809523812],'String',{'Best T2 solution'},'FontSize',15);
    end
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario3_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
%     figure; % Distribution around solution with best L1 and T1 measure (Scenario-II)
%     labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
%     colormap('jet');
%     b = bar(BL1T1Dist,'FaceColor','flat');
%     hAx = gca; % get a variable for the current axes handle
%     str = {'Best T1 sol.','Best L1 sol.'};
%     hAx.XTickLabel = str; % label the ticks
%     for k = 1:size(BL1T1Dist,2)
%         b(k).CData = k;
%     end
%     ylabel('No. of solutions');
%     legend(labels,'location','SouthEastOutside');
%     set(gca,'YScale','log','fontsize',15);ylim([1 1000]);
%     filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Type1','_Theoretical_T1Distribution');
%     saveas(gcf,filename);
%     print(filename,'-depsc2','-r300');
    
    
%     figure; % Distribution around solution with best L1 and T2 measure (Scenario-III)
%     labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
%     colormap('jet');
%     b = bar(BL1T2Dist,'FaceColor','flat');
%     hAx = gca; % get a variable for the current axes handle
%     str = {'Best T2 sol.','Best L1 sol.'};
%     hAx.XTickLabel = str; % label the ticks
%     for k = 1:size(BL1T2Dist,2)
%         b(k).CData = k;
%     end
%     ylabel('No. of solutions');
%     legend(labels,'location','SouthEastOutside');
%     set(gca,'YScale','log','fontsize',15);ylim([1 1000]);
%     filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Type2','_Theoretical_T2Distribution');
%     saveas(gcf,filename);
%     print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 6(d): Trade-offs between L1 and T1 measure (for Scenario-II)
    plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('T1');ylabel('L1 (normalized)');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_NDL1vsT1');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 6(e): Trade-offs between L1 and T2 measure (for Scenario-III)
    plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('T2');ylabel('L1 (normalized)');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_NDL1vsT2');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
end
% 
% 
%% Manuscript theoretical figures: Figure 7 (for deb2dk4 problem)
% Problem specifications
problem_name = 'deb2dk4_m'; 
objnum = 2;
def.spacing = 99;nSOI_all = [2,3,4,5,6];

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
UB = prob.range(:,2)';LB = prob.range(:,1)'; % zeros
def.perc_frac = [10 20 30 40 50 60 70 80];

% Evaluation
x = linspace(0,1,1000)';
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values

for i = 1:length(nSOI_all)
    def.nSOI = nSOI_all(i);
%     Knee id identification
    [order,SOIs,~,~,~] = S1Order(f,def);
    original_knee = f(SOIs,:);
    
%     L1 norm and T1 and T2 measure of all data
    def.type = 1;
    [ordert1,SOIT1,LT1,~,~,~,ND_L1vsT1] = S2S3Order(x,f,def,prob);
    def.type = 2;
    [ordert2,SOIT2,LT2,~,~,~,ND_L1vsT2] = S2S3Order(x,f,def,prob);

%     Figures
    figure; % Figure 7(a): 2 SOIs and ordered solutions for Scenario-I
    kn_order = f(order,:);
    scatter(kn_order(:,1),kn_order(:,2),10,(1:size(kn_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(original_knee(:,1),original_knee(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario1_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');

    figure; % Figure 7(b): 2 SOIs and ordered solutions for Scenario-II
    T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
    scatter(T1_order(:,1),T1_order(:,2),10,(1:size(T1_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(f(ND_L1vsT1,1),f(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T1(:,1),bestL1T1(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    if def.nSOI == 4
        annotation('textarrow',[0.4875 0.446428571428571],[0.626190476190476 0.530952380952381],'String',{'Best T1 solution'},'FontSize',15);
        annotation('textarrow',[0.416071428571428 0.453571428571429],[0.311904761904762 0.421428571428572],'String',{'Best L1 solution'},'FontSize',15);
    end
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario2_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 7(c): 2 SOIs and ordered solutions for Scenario-III
    T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
    scatter(T2_order(:,1),T2_order(:,2),10,(1:size(T2_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(f(ND_L1vsT2,1),f(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T2(:,1),bestL1T2(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);
    if def.nSOI == 4
        annotation('textarrow',[0.275 0.2375],[0.854761904761905 0.752380952380953],'String',{'Best T2 solution'},'FontSize',15);
        annotation('textarrow',[0.405357142857143 0.453571428571429],[0.330952380952381 0.423809523809524],'String',{'Best L1 solution'},'FontSize',15);
    end
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_Scenario3_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');

    
    figure; % Figure 7(d): Trade-offs between L1 and T1 measure (for Scenario-II)
    plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('T1');ylabel('L1 (normalized)');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_NDL1vsT1');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 7(e): Trade-offs between L1 and T2 measure (for Scenario-III)
    plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('T2');ylabel('L1 (normalized)');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(problem_name,'_nSOI_',num2str(def.nSOI),'_NDL1vsT2');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
end


% 
%% Manuscript theoretical figures: Figure 8 (for deb3dk1 problem)
% Problem specifications
problem_name = 'deb3dk1_m'; 
objnum = 3;
def.spacing = 21;def.nSOI = 1;

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
def.perc_frac = [10 20 30 40 50 60 70 80];

% Evaluation
[v1,v2] = meshgrid(0:.01:1,0:.01:1);
x = [reshape(v1,size(v1,1)*size(v1,2),1) reshape(v2,size(v2,1)*size(v2,2),1)];
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values

% Knee id identification
[order,SOIs,~,~,~] = S1Order(f,def);
original_knee = f(SOIs,:);

def.type = 1;
[ordert1,SOIT1,LT1,~,~,~,ND_L1vsT1] = S2S3Order(x,f,def,prob);
def.type = 2;
[ordert2,SOIT2,LT2,~,~,~,ND_L1vsT2] = S2S3Order(x,f,def,prob);


% Figures
figure; % 4 SOIs and ordered solutions for Scenario-I
kn_order = f(order,:);
labels = {'Ordered Sol.','SOI'};
scatter3(kn_order(:,1),kn_order(:,2),kn_order(:,3),10,(1:size(kn_order,1))');colorbar;hold on;
plot3(original_knee(:,1),original_knee(:,2),original_knee(:,3),'s','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(132,18);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario1_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 8(a): 4 SOIs and ordered solutions for Scenario-II
T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
labels = {'Ordered Sol.','ND: L1vsT1','SOI'};
scatter3(T1_order(:,1),T1_order(:,2),T1_order(:,3),10,(1:size(T1_order,1))');colorbar;hold on;
plot3(f(ND_L1vsT1,1),f(ND_L1vsT1,2),f(ND_L1vsT1,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot3(bestL1T1(:,1),bestL1T1(:,2),bestL1T1(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(131,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 8(b): 4 SOIs and ordered solutions for Scenario-III
T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
labels = {'Ordered Sol.','ND: L1vsT2','SOI'};
scatter3(T2_order(:,1),T2_order(:,2),T2_order(:,3),10,(1:size(T2_order,1))');colorbar;hold on;
plot3(f(ND_L1vsT2,1),f(ND_L1vsT2,2),f(ND_L1vsT2,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot3(bestL1T2(:,1),bestL1T2(:,2),bestL1T2(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(131,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 8(c): Variable space for trade-off solutions obtained for Scenario-II
T1_order_x = x(ordert1,:);bestL1T1_x = x(SOIT1,:);
scatter(T1_order_x(:,1),T1_order_x(:,2),10,(1:size(T1_order_x,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(T1_order_x(ND_L1vsT1,1),T1_order_x(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T1_x(:,1),bestL1T1_x(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);legend('Orientation','horizontal','location','NorthOutside');
filename = strcat(problem_name,'_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 8(d): Variable space for trade-off solutions obtained for Scenario-III
T2_order_x = x(ordert2,:);bestL1T2_x = x(SOIT2,:);
scatter(T2_order_x(:,1),T2_order_x(:,2),10,(1:size(T2_order_x,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(T2_order_x(ND_L1vsT2,1),T2_order_x(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T2_x(:,1),bestL1T2_x(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);legend('Orientation','horizontal','location','NorthOutside');
filename = strcat(problem_name,'_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Trade-offs between L1 and T1 measure (for Scenario-II)
plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('T1');ylabel('L1 (normalized)');
set(gca,'fontsize',15);legend('show');
filename = strcat(problem_name,'_NDL1vsT1');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Trade-offs between L1 and T2 measure (for Scenario-III)
plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('T2');ylabel('L1 (normalized)');
set(gca,'fontsize',15);legend('show');
filename = strcat(problem_name,'_NDL1vsT2');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% 
%% Manuscript theoretical figures: Figure 9 (for deb3dk4 problem)
% Problem specifications
problem_name = 'deb3dk4_m'; 
objnum = 3;
def.spacing = 21;def.nSOI = 4;

% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
def.perc_frac = [10 20 30 40 50 60 70 80];

% Evaluation
[v1,v2] = meshgrid(0:.01:1,0:.01:1);
x = [reshape(v1,size(v1,1)*size(v1,2),1) reshape(v2,size(v2,1)*size(v2,2),1)];
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values

% Knee id identification
[order,SOIs,~,~,~] = S1Order(f,def);
original_knee = f(SOIs,:);

% L1 norm and T1 and T2 measure of all data
def.type = 1;
[ordert1,SOIT1,LT1,~,~,~,ND_L1vsT1] = S2S3Order(x,f,def,prob);
def.type = 2;
[ordert2,SOIT2,LT2,~,~,~,ND_L1vsT2] = S2S3Order(x,f,def,prob);

% Figures
figure; % 4 SOIs and ordered solutions for Scenario-I
kn_order = f(order,:);
labels = {'Ordered Sol.','SOI'};
scatter3(kn_order(:,1),kn_order(:,2),kn_order(:,3),10,(1:size(kn_order,1))');colorbar;hold on;
plot3(original_knee(:,1),original_knee(:,2),original_knee(:,3),'s','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(132,18);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario1_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 9(a): 4 SOIs and ordered solutions for Scenario-II
T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
labels = {'Ordered Sol.','ND: L1vsT1','SOI'};
scatter3(T1_order(:,1),T1_order(:,2),T1_order(:,3),10,(1:size(T1_order,1))');colorbar;hold on;
plot3(f(ND_L1vsT1,1),f(ND_L1vsT1,2),f(ND_L1vsT1,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot3(bestL1T1(:,1),bestL1T1(:,2),bestL1T1(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(131,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 9(b): 4 SOIs and ordered solutions for Scenario-III
T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
labels = {'Ordered Sol.','ND: L1vsT2','SOI'};
scatter3(T2_order(:,1),T2_order(:,2),T2_order(:,3),10,(1:size(T2_order,1))');colorbar;hold on;
plot3(f(ND_L1vsT2,1),f(ND_L1vsT2,2),f(ND_L1vsT2,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot3(bestL1T2(:,1),bestL1T2(:,2),bestL1T2(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(131,13);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend(labels,'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 max(f(:,1))]);ylim([0 max(f(:,2))]);zlim([0 max(f(:,3))]);
filename = strcat(problem_name,'_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 9(c): Variable space for trade-off solutions obtained for Scenario-II
T1_order_x = x(ordert1,:);bestL1T1_x = x(SOIT1,:);
scatter(T1_order_x(:,1),T1_order_x(:,2),10,(1:size(T1_order_x,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(T1_order_x(ND_L1vsT1,1),T1_order_x(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T1_x(:,1),bestL1T1_x(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);legend('Orientation','horizontal','location','NorthOutside');
annotation('textarrow',[0.335714285714286 0.3],[0.742857142857143 0.652380952380952],'TextBackgroundColor',[1 1 1],'String',{'Best L1 Solution'},'FontSize',15);
annotation('textarrow',[0.516071428571428 0.482142857142857],[0.583333333333333 0.495238095238095],'TextBackgroundColor',[1 1 1],'String',{'Best T1 Solution'},'FontSize',15);
filename = strcat(problem_name,'_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 9(d): Variable space for trade-off solutions obtained for Scenario-III
T2_order_x = x(ordert2,:);bestL1T2_x = x(SOIT2,:);
scatter(T2_order_x(:,1),T2_order_x(:,2),10,(1:size(T2_order_x,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(T2_order_x(ND_L1vsT2,1),T2_order_x(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T2_x(:,1),bestL1T2_x(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);legend('Orientation','horizontal','location','NorthOutside');
annotation('textarrow',[0.353571428571428 0.303571428571429],[0.461904761904762 0.364285714285714],'TextBackgroundColor',[1 1 1],...
    'String',{'Best L1 Solution'},'FontSize',15);
annotation('textarrow',[0.417857142857143 0.310714285714286],[0.235714285714286 0.188095238095238],'TextBackgroundColor',[1 1 1],...
    'String',{'Best T2 Solution'},'FontSize',15);
filename = strcat(problem_name,'_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Trade-offs between L1 and T1 measure (for Scenario-II)
plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
ylabel('L1 (normalized)');xlabel('T1');
set(gca,'fontsize',15);legend('show');
filename = strcat(problem_name,'_NDL1vsT1');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Trade-offs between L1 and T2 measure (for Scenario-III)
plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
ylabel('L1 (normalized)');xlabel('T2');
set(gca,'fontsize',15);legend('show');
filename = strcat(problem_name,'_NDL1vsT2');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% 
% % 
%% Online figures in the manuscript: Figure 10 & 11 (for do2dk problem)
% Problem specifications
def.problem_name = 'do2dk';
def.nf = 2;
def.spacing = 99;
def.nSOI_all = [2];
% 
% Load the problem
funh = str2func(def.problem_name);
prob = funh(def.nf);

for i = 1:length(def.nSOI_all)
    def.nSOI = def.nSOI_all(i);
    % Load data
    def.type = 0;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
    % Knee id identification
    [order,SOIs,~,~,fronts] = S1Order(f,def);
    fnd = f(fronts{1},:);
    original_knee = f(SOIs,:);
       
    % Figures
    figure; % Figure 10(a): Identification of nSOI for Scenario-I
    kn_order = f(order,:);
    scatter(kn_order(:,1),kn_order(:,2),10,(1:size(kn_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(original_knee(:,1),original_knee(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 10]);ylim([0 10]);
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    % Load data
    def.type = 1;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    x = Archive(FeasId,3:2+prob.nx);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
    UB = prob.range(:,2)';LB = prob.range(:,1)';
    def.perc_frac = [10 20 30 40 50 60 70 80];
    % L1 norm and T1 and T2 measure of all data
    [ordert1,SOIT1,LT1,ideal,nadir,fronts,ND_L1vsT1] = S2S3Order(x,f,def,prob);
    fnd = f(fronts{1},:);
        
    % Best L1 distribution (T1 measure) and Best L1 distribution (T2 measure)
    [~,~,T1_matrix,~] = sol_measures(x,f,def.perc_frac,LB,UB,ideal,nadir);
    BL1T1Dist = [T1_matrix(ND_L1vsT1(1),:);T1_matrix(ND_L1vsT1(2),:)];
        
    % Figures
    figure; % Figure 10(b): trade-off set of solutions for Scenario-II
    T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
    scatter(T1_order(:,1),T1_order(:,2),10,(1:size(T1_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(f(ND_L1vsT1,1),f(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T1(:,1),bestL1T1(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 15]);ylim([0 10]);
    if def.nSOI == 2
        annotation('textarrow',[0.317857142857143 0.2125],[0.519047619047619 0.247619047619048],'String',{'Best L1 solution'},'FontSize',15);
        annotation('textarrow',[0.614285714285714 0.557142857142857],[0.516666666666667 0.302380952380952],'String',{'Best T1 solution'},'FontSize',15);
    end
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(a): trade-offs between L1 vs T1 measure for Scenario-II
    plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    ylabel('L1 (normalized)');xlabel('T1');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_NDL1vsT1');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(c): density of solutions around solution with best L1 and best T1 for Scenario-II
    labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
    colormap('jet');
    b = bar(BL1T1Dist,'FaceColor','flat');
    hAx=gca; % get a variable for the current axes handle
    str = {'Best T1 sol.','Best L1 sol.'};
    hAx.XTickLabel = str; % label the ticks
    for kk = 1:size(BL1T1Dist,2)
        b(kk).CData = kk;
    end
    ylabel('No. of solutions');
    legend(labels,'location','SouthEastOutside');
    set(gca,'YScale','log','fontsize',15);ylim([10 10000]);
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_T1Distribution');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    % Load data
    def.type = 2;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    x = Archive(FeasId,3:2+prob.nx);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
    UB = prob.range(:,2)';LB = prob.range(:,1)';
    def.perc_frac = [10 20 30 40 50 60 70 80];
 
    def.type = 2;
    [ordert2,SOIT2,LT2,ideal,nadir,fronts,ND_L1vsT2] = S2S3Order(x,f,def,prob);
    fnd = f(fronts{1},:);
    [~,~,T1_matrix,T2_matrix] = sol_measures(x,f,def.perc_frac,LB,UB,ideal,nadir);
    BL1T2Dist = [T2_matrix(ND_L1vsT2(1),:);T2_matrix(ND_L1vsT2(2),:)];   
    
    % Figures
    figure; % Figure 10(c): trade-off set of solutions for Scenario-III
    T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
    scatter(T2_order(:,1),T2_order(:,2),10,(1:size(T2_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(f(ND_L1vsT2,1),f(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T2(:,1),bestL1T2(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 15]);ylim([0 10]);
    if def.nSOI == 2
        annotation('textarrow',[0.551785714285714 0.494642857142857],[0.585714285714286 0.430952380952381],'String',{'Best T2 solution'},'FontSize',15);
        annotation('textarrow',[0.301785714285714 0.183928571428571],[0.690476190476191 0.342857142857143],'String',{'Best L1 solution'},'FontSize',15);
    end
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(b): trade-offs between L1 vs T2 measure for Scenario-III
    plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    ylabel('L1 (normalized)');xlabel('T2');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_NDL1vsT2');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(d): density of solutions around solution with best L1 and best T2 for Scenario-III
    labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
    colormap('jet');
    b = bar(BL1T2Dist,'FaceColor','flat');
    hAx = gca; % get a variable for the current axes handle
    str = {'Best T2 sol.','Best L1 sol.'};
    hAx.XTickLabel = str; % label the ticks
    for kk = 1:size(BL1T2Dist,2)
        b(kk).CData = kk;
    end
    ylabel('No. of solutions');
    legend(labels,'location','SouthEastOutside');
    set(gca,'YScale','log','fontsize',15);ylim([10 10000]);
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_T2Distribution');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
end


%% Online figures in the manuscript: Figure 12 (for deb2dk4 problem)
% Problem specifications
def.problem_name = 'deb2dk4';
def.nf = 2;
def.spacing = 99;
def.nSOI_all = [2,3,4,5,6];

% Load the problem
funh = str2func(def.problem_name);
prob = funh(def.nf);

for i = 1:length(def.nSOI_all)
    def.nSOI = def.nSOI_all(i);
%     Load data
    def.type = 0;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
%     Knee id identification
    [order,SOIs,~,~,fronts] = S1Order(f,def);
    fnd = f(fronts{1},:);
    original_knee = f(SOIs,:);
       
%     Figures
    figure; % Figure 10(a): Identification of nSOI for Scenario-I
    kn_order = f(order,:);
    scatter(kn_order(:,1),kn_order(:,2),10,(1:size(kn_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(original_knee(:,1),original_knee(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 15]);ylim([0 15]);
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
%     Load data
    def.type = 1;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    x = Archive(FeasId,3:2+prob.nx);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
    UB = prob.range(:,2)';LB = prob.range(:,1)';
    def.perc_frac = [10 20 30 40 50 60 70 80];
%     L1 norm and T1 and T2 measure of all data
    [ordert1,SOIT1,LT1,ideal,nadir,fronts,ND_L1vsT1] = S2S3Order(x,f,def,prob);
    fnd = f(fronts{1},:);
        
%     Figures
    figure; % Figure 10(b): trade-off set of solutions for Scenario-II
    T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
    scatter(T1_order(:,1),T1_order(:,2),10,(1:size(T1_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(f(ND_L1vsT1,1),f(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T1(:,1),bestL1T1(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 15]);ylim([0 15]);
    if def.nSOI == 4
        annotation('textarrow',[0.264285714285714 0.253571428571429],[0.254761904761905 0.385714285714286],'String',{'Best L1 solution'},'FontSize',15);
        annotation('textarrow',[0.523214285714286 0.692857142857143],[0.619047619047619 0.55952380952381],'String',{'Best T1 solution'},'FontSize',15);
    end
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(a): trade-offs between L1 vs T1 measure for Scenario-II
    plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    ylabel('L1 (normalized)');xlabel('T1');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_NDL1vsT1');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
%     Load data
    def.type = 2;
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    FeasId = find(Archive(:,end-1) == 0);
    x = Archive(FeasId,3:2+prob.nx);
    f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
    UB = prob.range(:,2)';LB = prob.range(:,1)';
    def.perc_frac = [10 20 30 40 50 60 70 80];
    [ordert2,SOIT2,LT2,~,~,fronts,ND_L1vsT2] = S2S3Order(x,f,def,prob);
    fnd = f(fronts{1},:);
    
%     Figures
    figure; % Figure 10(c): trade-off set of solutions for Scenario-III
    T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
    scatter(T2_order(:,1),T2_order(:,2),10,(1:size(T2_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
    plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
    plot(f(ND_L1vsT2,1),f(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
    plot(bestL1T2(:,1),bestL1T2(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    xlabel('f_1');ylabel('f_2');
    legend('location','NorthEast');
    set(gca,'fontsize',15);xlim([0 20]);ylim([0 20]);
    if def.nSOI == 4
        annotation('textarrow',[0.453571428571429 0.278571428571429],[0.342857142857143 0.280952380952381],'String',{'Best L1 solution'},'FontSize',15);
        annotation('textarrow',[0.551785714285714 0.6125],[0.585714285714286 0.811904761904762],'String',{'Best T2 solution'},'FontSize',15);
    end
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
    
    
    figure; % Figure 11(b): trade-offs between L1 vs T2 measure for Scenario-III
    plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
    plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
    box on;ax = gca;ax.BoxStyle = 'full';
    ylabel('L1 (normalized)');xlabel('T2');
    set(gca,'fontsize',15);legend('show');
    filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_NDL1vsT2');
    saveas(gcf,filename);
    print(filename,'-depsc2','-r300');
end


%% Online figures in the manuscript: Figure 13 (for deb3dk1 problem)
% Problem specifications
def.problem_name = 'deb3dk1';
def.nf = 3;
def.spacing = 21;
def.nSOI = 1;
def.min_knee_dist = 1e-1;
 
% Load the problem
funh = str2func(def.problem_name);
prob = funh(def.nf);

problem_name = 'deb3dk1_m'; 
objnum = 3;
funh1 = str2func(problem_name);
prob1 = funh1(objnum);
[v1,v2] = meshgrid(0:.01:1,0:.01:1);
xx = [reshape(v1,size(v1,1)*size(v1,2),1) reshape(v2,size(v2,1)*size(v2,2),1)];
func = str2func(problem_name);
[ff,~] = func(prob1.nf,xx); % objective values


% Load data
def.type = 0;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
% Knee id identification
[order,SOIs,ideal,nadir,fronts] = S1Order(f,def);
fnd = f(fronts{1},:);
original_knee = f(SOIs,:);

% Figures
figure; % Figure 13(a): Identification of nSOI for Scenario-I
kn_order = f(order,:);
% labels = {'Ordered Sol.','SOI'};
p1 = scatter3(kn_order(:,1),kn_order(:,2),kn_order(:,3),10,(1:size(kn_order,1))');colorbar;hold on;
plot3(ff(:,1),ff(:,2),ff(:,3),'k.');
p3 = plot3(original_knee(:,1),original_knee(:,2),original_knee(:,3),'s','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(97,17);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend([p1,p3],{'Ordered Sol','SOI'},'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 10]);ylim([0 10]);zlim([0 10]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Load data
def.type = 1;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
UB = prob.range(:,2)';LB = prob.range(:,1)';
def.perc_frac = [10 20 30 40 50 60 70 80];
% L1 norm and T1 and T2 measure of all data
[ordert1,SOIT1,LT1,ideal,nadir,fronts,ND_L1vsT1] = S2S3Order(x,f,def,prob);
fnd = f(fronts{1},:);

% Figures
figure; % Figure 13(b): trade-off set of solutions for Scenario-II
T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
p1 = scatter3(T1_order(:,1),T1_order(:,2),T1_order(:,3),10,(1:size(T1_order,1))');colorbar;hold on;
plot3(ff(:,1),ff(:,2),ff(:,3),'k.');
p2 = plot3(f(ND_L1vsT1,1),f(ND_L1vsT1,2),f(ND_L1vsT1,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
p3 = plot3(bestL1T1(:,1),bestL1T1(:,2),bestL1T1(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(97,17);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend([p1,p2,p3],{'Ordered Sol.','ND: L1vsT1','SOI'},'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 10]);ylim([0 10]);zlim([0 10]);
set(gca,'fontsize',15);hold off;
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 13(d): Trade-offs between L1 and T1 measure (for Scenario-II)
plot(LT1(ND_L1vsT1,1),LT1(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
ylabel('L1 (normalized)');xlabel('T1');
set(gca,'fontsize',15);legend('show');
filename = strcat(def.problem_name,'_Online_NDL1vsT1');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Load data
def.type = 2;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
UB = prob.range(:,2)';LB = prob.range(:,1)';
def.perc_frac = [10 20 30 40 50 60 70 80];
% L1 norm and T1 and T2 measure of all data
[ordert2,SOIT2,LT2,ideal,nadir,fronts,ND_L1vsT2] = S2S3Order(x,f,def,prob);
fnd = f(fronts{1},:);

% Figures
figure; % Figure 13(c): trade-off set of solutions for Scenario-III
T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
p1 = scatter3(T2_order(:,1),T2_order(:,2),T2_order(:,3),10,(1:size(T2_order,1))');colorbar;hold on;
plot3(ff(:,1),ff(:,2),ff(:,3),'k.');
p2 = plot3(f(ND_L1vsT2,1),f(ND_L1vsT2,2),f(ND_L1vsT2,3),'o','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
p3 = plot3(bestL1T2(:,1),bestL1T2(:,2),bestL1T2(:,3),'s','DisplayName','SOI','MarkerSize',15,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';view(97,17);
xlabel('f_1');ylabel('f_2');zlabel('f_3');
legend([p1,p2,p3],{'Ordered Sol.','ND: L1vsT2','SOI'},'Orientation','horizontal','location','NorthOutside');
set(gca,'fontsize',15);
xlim([0 15]);ylim([0 15]);zlim([0 15]);
set(gca,'fontsize',15);hold off;
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 13(e): Trade-offs between L1 and T1 measure (for Scenario-III)
plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
ylabel('L1 (normalized)');xlabel('T2');
set(gca,'fontsize',15);legend('show');
filename = strcat(def.problem_name,'_Online_NDL1vsT2');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% 
%% Online figures in the manuscript: Figure 14 (for welded beam design problem)
% Problem specifications
def.problem_name = 'welded_beam';
def.nf = 2;
def.spacing = 99;
def.nSOI = 1;
def.min_knee_dist = 1e-1;
def.run = 1;

% Load the problem
funh = str2func(def.problem_name);
prob = funh(def.nf);
% Load data
def.type = 0;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
% Knee id identification
[order,SOIs,ideal,nadir,fronts] = S1Order(f,def);
fnd = f(fronts{1},:);
original_knee = f(SOIs,:);

% Figures
figure; % Figure 14(a): Identification of nSOI for Scenario-I
kn_order = f(order,:);
scatter(kn_order(:,1),kn_order(:,2),10,(1:size(kn_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
plot(original_knee(:,1),original_knee(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('f_1');ylabel('f_2');
legend('location','NorthEast');
set(gca,'fontsize',15);xlim([0 60]);ylim([0 0.01]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');
%  
% Load data
def.type = 1;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
UB = prob.range(:,2)';LB = prob.range(:,1)';
def.perc_frac = [10 20 30 40 50 60 70 80];
% L1 norm and T1 and T2 measure of all data
[ordert1,SOIT1,LT1,ideal,nadir,fronts,ND_L1vsT1] = S2S3Order(x,f,def,prob);
fnd = f(fronts{1},:);

% Figures
figure; % Figure 14(b): trade-off set of solutions for Scenario-II
T1_order = f(ordert1,:);bestL1T1 = f(SOIT1,:);
scatter(T1_order(:,1),T1_order(:,2),10,(1:size(T1_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
plot(f(ND_L1vsT1,1),f(ND_L1vsT1,2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T1(:,1),bestL1T1(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('f_1');ylabel('f_2');
legend('location','NorthEast');
set(gca,'fontsize',15);xlim([0 60]);ylim([0 0.01]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 14(d): trade-offs between L1 vs T1 measure for Scenario-II
plot(LT1(ND_L1vsT1{1},1),LT1(ND_L1vsT1{1},2),'o','DisplayName','ND: L1vsT1','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT1(SOIT1,1),LT1(SOIT1,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('L1 (normalized)');ylabel('T1');
set(gca,'fontsize',15);legend('show');
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Online_NDL1vsT1');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Load data
def.type = 2;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
UB = prob.range(:,2)';LB = prob.range(:,1)';
def.perc_frac = [10 20 30 40 50 60 70 80];
[ordert2,SOIT2,LT2,~,~,fronts,ND_L1vsT2] = S2S3Order(x,f,def,prob);
fnd = f(fronts{1},:);

% Figures
figure; % Figure 13(c): trade-off set of solutions for Scenario-III
T2_order = f(ordert2,:);bestL1T2 = f(SOIT2,:);
scatter(T2_order(:,1),T2_order(:,2),10,(1:size(T2_order,1))','DisplayName','Ordered Sol.');colorbar;hold on;
plot(fnd(:,1),fnd(:,2),'.','Color',[0.4940 0.1840 0.5560],'DisplayName','ND Sol.','MarkerSize',12);
plot(f(ND_L1vsT2,1),f(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');
plot(bestL1T2(:,1),bestL1T2(:,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('f_1');ylabel('f_2');
legend('location','NorthEast');
set(gca,'fontsize',15);xlim([0 60]);ylim([0 0.01]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_AllSolns_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 13(e): trade-offs between L1 vs T2 measure for Scenario-III
plot(LT2(ND_L1vsT2,1),LT2(ND_L1vsT2,2),'o','DisplayName','ND: L1vsT2','MarkerSize',5,'MarkerFaceColor','k','MarkerEdgeColor','k');hold on;
plot(LT2(SOIT2,1),LT2(SOIT2,2),'s','DisplayName','SOI','MarkerSize',12,'MarkerFaceColor','r');
box on;ax = gca;ax.BoxStyle = 'full';
xlabel('L1 (normalized)');ylabel('T2');
set(gca,'fontsize',15);legend('show');
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Online_NDL1vsT2');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% 
% 
%% Online figures in the manuscript: Figure 15 and 16 (for wind turbine design problem)
def.problem_name = 'Windturbine_MOP';
def.spacing = 15;
def.nf = 5;
def.nSOI = 1;
funh = str2func(def.problem_name);
prob = funh(def.nf);
LB = prob.range(:,1)';UB = prob.range(:,2)';
def.perc_frac = [10 20 30 40 50 60 70 80];
def.type_all = [0 1 2];
AllArchive = []; % Finding overall ideal and nadir from all archived types
for j = 1:length(def.type_all)
    def.type = def.type_all(j);
    load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
    AllArchive = [AllArchive;Archive];
end
AllFeasId = find(AllArchive(:,end-1)==0);
Allf = AllArchive(AllFeasId,3+prob.nx:2+prob.nx+prob.nf);
[Allid_fronts,~,~,~] = E_NDSort_c(Allf);
Allid = Allid_fronts{1};
Allfnd = Allf(Allid,:);
Allfnd = unique(Allfnd,'rows','stable');
ideal = min(Allfnd);nadir = max(Allfnd);
count = 2;tmp_fnd = Allfnd;
while sum(ideal-nadir) == 0 && count <= length(id_fronts)
    tmp_fnd = [tmp_fnd;Allf(id_fronts{count},:)];
    ideal = min(tmp_fnd);nadir = max(tmp_fnd);
    count = count + 1;
end

% Figure 14: For Scenario-I
def.type = 0;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1)==0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
% Delete solns beyond nadir
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
f_norm(f_norm>1) = NaN;
DeletIds = find(isnan(sum(f_norm,2)));
x(DeletIds,:) = [];f(DeletIds,:) = [];f_norm(DeletIds,:) = [];

% L1 norm and T1 and T2 measure of all data
L1 = ones(size(f_norm,1),size(f_norm,2))-f_norm;
L1(L1<0) = 0;
L1_norm = sum(abs(L1),2);
[T1_order,T2_order,T1_matrix,T2_matrix] = sol_measures(x,f,def.perc_frac,LB,UB,ideal,nadir);
add_order1 = (T1_order-min(T1_order))/(max(T1_order)-min(T1_order));
add_order2 = (T2_order-min(T2_order))/(max(T2_order)-min(T2_order));

% ND of L1 vs T1 and L1 vs T2
L1vsT1 = [-L1_norm -add_order1];
L1vsT2 = [-L1_norm -add_order2];
[id_fronts1,~,~,~] = E_NDSort_c(L1vsT1);
ND_L1vsT1 = id_fronts1{1};
[id_fronts2,~,~,~] = E_NDSort_c(L1vsT2);
ND_L1vsT2 = id_fronts2{1};

BL1T1Type1Dist = T1_matrix(ND_L1vsT1(1),:);
BL1T2Type2Dist = T2_matrix(ND_L1vsT2(1),:);
SpiderData1 = [f_norm(ND_L1vsT1(1),:);ones(1,size(f_norm,2))];


% Figure
% Figure 14(a): Objective space of best L1 solution for Scenario-I
for k = 1:size(f_norm,2)
    lbl{k} = strcat('Obj-',num2str(k));
end
leg1 = {'Best L1' 'Nadir'};
spider(SpiderData1',[],[0 1],lbl,leg1);
set(gca,'fontsize',15);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Spider_BestL1T1Fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 14(b): Objective space of best L1 solution for Scenario-I
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
colormap('jet');
b = bar([BL1T1Type1Dist;nan(1,length(BL1T1Type1Dist))],'FaceColor','flat');
hAx = gca;
str = {};%'T1 measure of the best L1 solution'
hAx.XTickLabel = str; % label the ticks
for kk = 1:size(BL1T1Type1Dist,2)
    b(kk).CData = kk;
end
xlim([0.4 1.6]);
ylabel('No. of solutions');
legend(labels,'location','SouthEastOutside');
set(gca,'YScale','log','fontsize',15);ylim([1 10000]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Online_T1Distribution');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


figure; % Figure 14(c): T1 measure of best L1 solution for Scenario-I
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8'};
colormap('jet');
b = bar([BL1T2Type2Dist;nan(1,length(BL1T2Type2Dist))],'FaceColor','flat');
hAx = gca;
str = {};%'T2 measure of the best L1 solution)'
hAx.XTickLabel = str;
for kk = 1:size(BL1T2Type2Dist,2)
    b(kk).CData = kk;
end
xlim([0.4 1.6]);
ylabel('No. of solutions');
legend(labels,'location','SouthEastOutside');
set(gca,'YScale','log','fontsize',15);ylim([1 10000]);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Online_T2Distribution');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Figure 15: For Scenario-II
def.type = 1;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1)==0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
% Delete solns beyond nadir
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
f_norm(f_norm>1) = NaN;
DeletIds = find(isnan(sum(f_norm,2)));
x(DeletIds,:) = [];f(DeletIds,:) = [];f_norm(DeletIds,:) = [];
[~,~,~,~,~,~,ND_L1vsT1] = S2S3Order(x,f,def,prob);
SpiderData1 = [[f_norm(ND_L1vsT1(2),:);f_norm(ND_L1vsT1(1),:)];ones(1,size(f_norm,2))];

% Figure
% Figure 15(a): Objective space of best L1 solution for Scenario-I
for k = 1:size(f_norm,2)
    lbl{k} = strcat('Obj-',num2str(k));
end
leg1={'Best L1' 'Best T1' 'Nadir'};
spider(SpiderData1',[],[0 1],lbl,leg1);
set(gca,'fontsize',15);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Spider_BestL1T1Fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

        
% Figure 15: For Scenario-III
def.type = 2;
load(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1)==0);
x = Archive(FeasId,3:2+prob.nx);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
% Delete solns beyond nadir
f_norm = (f-repmat(ideal,size(f,1),1))./repmat(nadir-ideal,size(f,1),1);
f_norm(f_norm>1) = NaN;
DeletIds = find(isnan(sum(f_norm,2)));
x(DeletIds,:) = [];f(DeletIds,:) = [];f_norm(DeletIds,:) = [];
[~,~,~,~,~,~,ND_L1vsT2] = S2S3Order(x,f,def,prob);
SpiderData2 = [[f_norm(ND_L1vsT2(2),:);f_norm(ND_L1vsT2(1),:)];ones(1,size(f_norm,2))];

% Figure 15(b): Objective space of best L1 solution for Scenario-I
for k = 1:size(f_norm,2)
    lbl{k} = strcat('Obj-',num2str(k));
end
leg1={'Best L1' 'Best T2' 'Nadir'};
spider(SpiderData2',[],[0 1],lbl,leg1);
set(gca,'fontsize',15);
filename = strcat(def.problem_name,'_Type',num2str(def.type),'_Spider_BestL1T1Fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');     


%% Move the figures to the folder
movefile('*.fig',MoveFigure);
movefile('*.eps',MoveFigure);
movefile('*.jpg',MoveFigure);
return




%% All illustrations in the revised manuscript
function sympart_illustration
%% Response figures 
% Problem specifications
problem_name = 'sympart1'; 
objnum = 2;nSOI = 1;
% Load the problem
funh = str2func(problem_name);
prob = funh(objnum);
UB = prob.range(:,2)';LB = prob.range(:,1)'; % zeros
def.perc_frac = [10 20 30 40 50 60 70 80];

%% Theoretical illustrations
x2 = [-10 0 10];x = [];
for i = 1:3
    for j = 1:3
        x = [x;[linspace(x2(j)-1,x2(j)+1,45)' repmat(x2(i),45,1)]]; 
    end
end
func = str2func(problem_name);
[f,~] = func(prob.nf,x); % objective values

% Sympart pareto (Figure 3)
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',10,'MarkerFaceColor','b','MarkerEdgeColor','b');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_Pareto_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',10,'MarkerFaceColor','b','MarkerEdgeColor','b');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_Pareto_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

def.nSOI = nSOI;def.spacing = 99;
aid = S1Order(f,def);
% % 
% Scenario-I (Figure 4)
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid(1:nSOI),1),x(aid(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario1_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid(1:nSOI),1),f(aid(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario1_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% 
% Scenario-II
def.type = 1;
def.nSOI = nSOI;def.spacing = 99;
[aid1,~,~,~,~,~,id_fronts] = S2S3Order(x,f,def,prob);

% nSOI
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid1(1:nSOI),1),x(aid1(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid1(1:nSOI),1),f(aid1(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');
% 
% nds
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(id_fronts,1),x(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_Tbefore_ND_Theoretical_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(id_fronts,1),f(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_Tbefore_ND_Theoretical_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% 
% Scenario-III
def.type = 2;
def.nSOI = nSOI;def.spacing = 99;
[aid2,~,~,~,~,~,id_fronts] = S2S3Order(x,f,def,prob);
% 
% nSOI
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid2(1:nSOI),1),x(aid2(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid2(1:nSOI),1),f(aid2(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Theoretical_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% nds
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(id_fronts,1),x(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_ND_Tbefore_Theoretical_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(id_fronts,1),f(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_ND_Tbefore_Theoretical_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');



% Online illustrations (Figure 5)
% Scenario-I
def.type = 0;
load(strcat(problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:4);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
def.nSOI = nSOI;def.spacing = 99;
[aid,~,~,~,id_fronts] = S1Order(f,def);

figure;
plot(x(:,1),x(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid(1:nSOI),1),x(aid(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario1_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid(1:nSOI),1),f(aid(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;xlim([0 4]);ylim([0 4]);
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario1_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Scenario-II
def.type = 1;
load(strcat(problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:4);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
def.nSOI = nSOI;def.spacing = 99;
[aid1,~,~,~,~,~,id_fronts] = S2S3Order(x,f,def,prob);

% nSOI
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid1(1:nSOI),1),x(aid1(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid1(1:nSOI),1),f(aid1(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;xlim([0 4]);ylim([0 4]);
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% nds
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(id_fronts,1),x(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_ND_Tbefore_Online_Scenario2_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(id_fronts,1),f(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;xlim([0 4]);ylim([0 4]);
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_ND_Tbefore_Online_Scenario2_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');


% Scenario-III
def.type = 2;
load(strcat(problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(nSOI),'_Archive_KneeSearch.mat'));
FeasId = find(Archive(:,end-1) == 0);
x = Archive(FeasId,3:4);
f = Archive(FeasId,3+prob.nx:2+prob.nx+prob.nf);
def.nSOI = nSOI;def.spacing = 99;
[aid2,~,~,~,~,~,id_fronts] = S2S3Order(x,f,def,prob);

figure;
plot(x(:,1),x(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(aid2(1:nSOI),1),x(aid2(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(aid2(1:nSOI),1),f(aid2(1:nSOI),2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;xlim([0 4]);ylim([0 4]);
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_Tbefore_Online_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

% nds
figure;
plot(x(:,1),x(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(x(id_fronts,1),x(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;
xlabel('x_1');ylabel('x_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_ND_Tbefore_Online_Scenario3_xspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');

figure;
plot(f(:,1),f(:,2),'.','MarkerSize',7,'MarkerFaceColor','b','MarkerEdgeColor','b');hold on;
plot(f(id_fronts,1),f(id_fronts,2),'p','MarkerSize',12,'MarkerFaceColor','r','MarkerEdgeColor','r');
grid on;xlim([0 4]);ylim([0 4]);
xlabel('f_1');ylabel('f_2');
set(gca,'fontsize',15);
filename = strcat(problem_name,'_nSOI_',num2str(nSOI),'_ND_Tbefore_Online_Scenario3_fspace');
saveas(gcf,filename);
print(filename,'-depsc2','-r300');
return


function [prob]=load_problem_definition(def)
funh=str2func(def.problem_name);
prob=funh(def.nf);
return