%%%%%%%%% Knee Final Code %%%%%%%%%%%%%%%%%%%%

Please cite the following papers if you use this algorithm.

%------------------------------- Copyright ------------------------------------
% Please cite the following paper if you use the code: 
%------------------------------------------------------------------------------
% Ray, T., Singh, H. K., Rahi, K. H., Rodemann, T., & Olhofer, M. (2022). Towards identification of 
% solutions of interest for multi-objective problems considering both objective and variable space 
% information. Applied Soft Computing, 119, 108505.
%------------------------------------------------------------------------------ 


%%%%%Steps to run the code%%%%%%%%%%%%

1. Specify parameters in the params.m file.
2. Run the multirun.m script.
3. All data will be stored in the data folder.
4. Run the illustration.m script to generate all the figures presented in the paper.
 