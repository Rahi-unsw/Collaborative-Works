%% Knee focussed search algorithm
% Please, check all the parameters in param.m before running it.
function Driver(path)
load('Parameters.mat');

% Load the Problem Definition
prob = load_problem_definition(def);

% Maximum Number of Function Evaluation
MNFE = def.NFE;rng(def.seed,'twister');

% Defining the upper and lower bound  of the variables
LB = prob.range(:,1)';UB = prob.range(:,2)';

% Initializing the population
X_pop = repmat(LB,def.pop_size,1)+(repmat(UB,def.pop_size,1)-repmat(LB,def.pop_size,1)).*(lhsdesign(def.pop_size,prob.nx));

% Evaluating the initial population of solutions
func = str2func(def.problem_name);
[F_pop,G_pop] = func(prob.nf,X_pop);

% Starting the Tapping Counter
counter = (1:size(F_pop,1))';
if (~isempty(G_pop))
    CVpop = nansum(nanmax(G_pop,0),2);
else
    G_pop = [];
    CVpop = zeros(size(F_pop,1),1);
end
sol_id = 1:size(counter,1);
Archive = [zeros(def.pop_size,1) sol_id' X_pop F_pop G_pop CVpop counter];

% Sorting the Initial Population
fid = find(Archive(:,end-1) == 0);
if (~isempty(fid))
    FF_pop = F_pop(fid,:);FX_pop = X_pop(fid,:);
    % This is for Scenario-I
    if (def.type == 0)
        order = S1Order(FF_pop,def);
    else
        order = S2S3Order(FX_pop,FF_pop,def,prob);
    end
    FX_pop = FX_pop(order,:);
else
    FX_pop = [];
end

% Ordering infeasible solutions
ifid = find(CVpop~=0);
if (~isempty(ifid))
    ICV = CVpop(ifid,:);
    IX_pop = X_pop(ifid,:);
    [~,idcv] = sort(ICV);
    IX_pop = IX_pop(idcv,:);
else
    IX_pop = [];
end

% Overall order
X_pop = [FX_pop;IX_pop];

% Generation Loop Starts from here
for k = 1:1e6
    % Generate offspring
    [parent_idx] = min(1:def.pop_size,randperm(def.pop_size));
    X_pop = X_pop(parent_idx',:);
    X_child = genetic_operator(LB,UB,def,prob,X_pop);
    
    % Uniqueness test of Offspring
    [X_child] = valid_offspring(X_child,Archive(:,3:2+prob.nx),def,prob,LB,UB);
    
    % Evaluating the offspeing population
    func = str2func(def.problem_name);
    [F_child,G_child] = func(prob.nf,X_child);
    
    % Update the Archive
    counter1 = (1:size(F_child,1))';
    counter = counter(end,:);
    counter = repmat(counter,size(counter1,1),1);
    counter = counter+counter1;
    if (~isempty(G_child))
        CVchild = nansum(nanmax(G_child,0),2);
    else
        G_child = [];
        CVchild = zeros(size(F_child,1),1);
    end
    sol_id = 1:size(counter,1);
    tmp = [X_child F_child G_child CVchild counter];
    Archive = [Archive; k*ones(size(counter,1),1) sol_id' tmp];
    
    % Ensuring Archive is Unique wrt x
    xx = Archive(:,3:2+prob.nx);
    [~,ids,~] = unique(xx,'rows','stable');
    Archive = Archive(ids,:);
    
    % Sorting the solutions evaluated so far
    X_pop = Archive(:,3:2+prob.nx);
    F_pop = Archive(:,3+prob.nx:2+prob.nx+prob.nf);
    if (prob.ng>0)
        G_pop = Archive(3+prob.nx+prob.nf:2+prob.nx+prob.nf+prob.ng);
    else
        G_pop = [];
    end
    
    % Ordering in terms of scenarios-I,II and III
    fid = find(Archive(:,end-1) == 0);
    if (~isempty(fid))
        FF_pop = F_pop(fid,:);FX_pop = X_pop(fid,:);
        % This is for Scenario-I
        if (def.type == 0)
            order = S1Order(FF_pop,def);
        else
            order = S2S3Order(FX_pop,FF_pop,def,prob);
        end
        FX_pop = FX_pop(order,:);
    else
        FX_pop = [];
    end
    
    % Ordering infeasible solutions
    cv = Archive(:,3+prob.nx+prob.nf+prob.ng);
    ifid = find(cv~=0);
    if (~isempty(ifid))
        ICV = cv(ifid,:);
        IX_pop = X_pop(ifid,:);
        [~,idcv] = sort(ICV);
        IX_pop = IX_pop(idcv,:);
    else
        IX_pop = [];
    end
    
    % Overall order
    X_pop = [FX_pop;IX_pop];
    
    % Termination Criteria
    disp(strcat(path,filesep,'NFE - ',num2str(Archive(end,end))));
    if Archive(end,end) >= MNFE
        break;
    else
        % Parent population for the next generation
        X_pop = X_pop(1:def.pop_size,:);
    end
end

% This is complete archive
save(strcat(def.problem_name,'_Type',num2str(def.type),'_nSOI_',num2str(def.nSOI),'_Archive_KneeSearch.mat'),'Archive','-mat');
return