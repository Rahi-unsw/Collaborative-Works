%% Running multiple problems
function multirun
clc;clear all;close all;warning off;
filename = mfilename;
motherfolderpath = which(filename);
motherfolder = fileparts(motherfolderpath);
cd(motherfolder);
addpath(genpath(motherfolder));
params;path = cd;count = 1;

for i=1:numel(def.problem_name_all)
    def.problem_name = def.problem_name_all{i};
    def.nf = def.nf_all(i);
    def.spacing = def.spacing_all(i);
    def.nf = def.nf_all(i);
    def.nSOI = def.nSOI_all(i);
    def.pop_size = def.pop_size_all(i);
    for k = 1:length(def.type_all)
        def.type = def.type_all(k);
        pth = strcat(cd,filesep,'Data',filesep,def.problem_name,filesep,'nSOI-',num2str(def.nSOI),filesep,'Type-',num2str(def.type));
        mkdir(pth);
        cd(pth);
        def.seed = 101;
        save('Parameters.mat', 'def');
        path1{count} = pth;
        count = count+1;
        cd(path);        
    end
end
cd(path);

clear param;
% parfor: utilize multiple core of PC.
numcores = feature('numcores');
parpool(numcores);
parfor i = 1:length(path1)
    cd(path1{i});
    disp(strcat('Running -> ',path1{i}));
    tic;
    Driver(path1{i});
    toc;
end
delete(gcp);
cd(path);
return