% def.type = 0; Only SOI
% def.type = 1; L1 and T1
% def.type = 2; L1 and T2

% Parameter for write function
def.display_gen = 0;

% Run Specific Input
def.NFE = 10000;

% Recombination parameters
def.prob_crossover = 1;              %User defined parameter
def.prob_mutation = 0.1;             %User defined parameter
def.distribution_crossover = 20;     %User defined parameter
def.distribution_mutation = 20;
% This is required for T1,T2 Measures
def.perc_frac = [10 20 30 40 50 60 70 80];

% % Problem specifications
% def.problem_name = 'do2dk';
% def.nf = 2;
% def.nSOI = 2;
% def.spacing = 99;

% def.problem_name = 'deb2dk4';
% def.nf = 2;
% def.nSOI = 4;
% def.spacing = 99;
% 
% def.problem_name = 'deb3dk1';
% def.nf = 3;
% def.nSOI = 1;
% def.spacing = 21;
% 
% def.problem_name = 'deb3dk4';
% def.nf = 3;
% def.nSOI = 4;
% def.spacing = 21;
% 
% def.problem_name = 'welded_beam';
% def.nf = 2;
% def.nSOI = 1;
% def.spacing = 99;
% 
% def.problem_name = 'Windturbine_MOP';
% def.spacing = 15;
% def.nf = 5;
% def.nSOI = 1;


def.problem_name_all = {'do2dk','do2dk','do2dk','deb2dk4','deb2dk4','deb2dk4','deb2dk4','deb2dk4','deb3dk1','deb3dk4','welded_beam','sympart1','sympart1'}; 
def.pop_size_all = [100,100,100,100,100,100,100,100,100,100,100,100,100];
def.spacing_all = [99,99,99,99,99,99,99,99,21,21,99,99,99];
def.nf_all = [2,2,2,2,2,2,2,2,3,3,2,2,2];
def.nSOI_all = [2,4,6,2,3,4,5,6,1,4,1,1,3];
def.type_all = [0,1,2];
def.no_runs = 1;








